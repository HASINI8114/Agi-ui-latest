// Preview-only stand-in for @siloverse/services: no login, synthetic review data.
export const sessionService = { ensure: () => true };
export const reviewService = { getLanding: async () => structuredClone((await import('./data/review/generate.js')).landing) };
