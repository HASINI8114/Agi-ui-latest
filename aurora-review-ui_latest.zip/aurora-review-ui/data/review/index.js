export { landing as default } from './generate.js';
