// Synthetic review program. Size and the estimate are one rule, used by the page.
// Small is 1–2 pages, medium 3–8, large 9 or more.
// Estimated minutes = pages × language weight × content weight × region weight × 4.
// English weighs 1, any other language 1.5. Normal content weighs 1, dense content 1.5.
// India is the home bench and weighs 1. A document from another region takes longer.

const REVIEWERS = [
  { reviewer: 'Sarah Jenkins', userId: 33385727, pace: 0.8, miss: 2, volume: 6 },
  { reviewer: 'Alex Mercer', userId: 73461994, pace: 0.92, miss: 4, volume: 5 },
  { reviewer: 'Carlos Gomez', userId: 68351882, pace: 1.05, miss: 6, volume: 4 },
  { reviewer: 'Priya Patel', userId: 75326491, pace: 1.55, miss: 22, volume: 3 },
  { reviewer: 'Maya Lin', userId: 21663941, pace: 1.25, miss: 10, volume: 3 },
  { reviewer: 'David Kim', userId: 21663942, pace: 1.35, miss: 14, volume: 3 },
  { reviewer: 'Lucas Silva', userId: 78755122, pace: 0.9, miss: 5, volume: 5 },
  { reviewer: 'Zoe Washington', userId: 78755123, pace: 0.88, miss: 3, volume: 4 },
  { reviewer: 'Hannah Okonkwo', userId: 41000001, pace: 0.84, miss: 3, volume: 6 },
  { reviewer: 'James Obrien', userId: 41000002, pace: 1.02, miss: 5, volume: 4 },
  { reviewer: 'Nina Kapoor', userId: 41000003, pace: 0.95, miss: 4, volume: 5 },
  { reviewer: 'Omar Haddad', userId: 41000004, pace: 1.18, miss: 9, volume: 3 },
  { reviewer: 'Elena Rossi', userId: 41000005, pace: 0.9, miss: 3, volume: 5 },
  { reviewer: 'Ben Cho', userId: 41000006, pace: 1.4, miss: 16, volume: 2 },
  { reviewer: 'Aisha Rahman', userId: 41000007, pace: 0.86, miss: 2, volume: 6 },
  { reviewer: 'Tom Becker', userId: 41000008, pace: 1.08, miss: 7, volume: 4 },
  { reviewer: 'Grace Adeyemi', userId: 41000009, pace: 0.93, miss: 4, volume: 5 },
  { reviewer: 'Noah Berg', userId: 41000010, pace: 1.22, miss: 11, volume: 3 },
  { reviewer: 'Chloe Martin', userId: 41000011, pace: 0.88, miss: 3, volume: 4 },
  { reviewer: 'Rajiv Mehta', userId: 41000012, pace: 1.48, miss: 18, volume: 2 },
  { reviewer: 'Sofia Alvarez', userId: 41000013, pace: 0.91, miss: 4, volume: 5 },
  { reviewer: 'Kenji Watanabe', userId: 41000014, pace: 1.0, miss: 5, volume: 4 },
  { reviewer: 'Laura Schmidt', userId: 41000015, pace: 0.85, miss: 2, volume: 6 },
  { reviewer: 'Andre Diallo', userId: 41000016, pace: 1.3, miss: 12, volume: 3 },
];

// weight scales how many documents finish. pace above 1 runs long. miss above 1 fails the senior sample more often.
const PROJECTS = [
  { projectId: 'A30045', projectName: 'Prime Video content review', client: 'Amazon', domain: 'Amazon Prime', weight: 1.6, pace: 0.9, miss: 0.55 },
  { projectId: 'A30110', projectName: 'Prime membership disputes', client: 'Amazon', domain: 'Amazon Prime', weight: 0.55, pace: 1.05, miss: 1.15 },
  { projectId: 'A30048', projectName: 'Now grocery claims', client: 'Amazon', domain: 'Amazon Now', weight: 0.95, pace: 1.28, miss: 1.7 },
  { projectId: 'A30111', projectName: 'Now pharmacy inquiries', client: 'Amazon', domain: 'Amazon Now', weight: 0.28, pace: 0.86, miss: 0.45 },
  { projectId: 'A30051', projectName: 'Clinical data inquiry', client: 'Northwind Health', domain: 'Clinical', weight: 0.7, pace: 1.42, miss: 2.1 },
  { projectId: 'A30062', projectName: 'Payer audit', client: 'Northwind Health', domain: 'Payer', weight: 0.32, pace: 0.94, miss: 0.7 },
  { projectId: 'A30120', projectName: 'Card disputes', client: 'Meridian Bank', domain: 'Retail banking', weight: 0.62, pace: 0.96, miss: 0.8 },
  { projectId: 'A30121', projectName: 'Loan file review', client: 'Meridian Bank', domain: 'Commercial credit', weight: 0.36, pace: 1.16, miss: 1.35 },
  { projectId: 'A30122', projectName: 'Safety incident review', client: 'Helios Energy', domain: 'Operations', weight: 0.48, pace: 1.22, miss: 1.65 },
  { projectId: 'A30123', projectName: 'Regulatory filing production', client: 'Helios Energy', domain: 'Regulatory', weight: 0.22, pace: 0.9, miss: 0.55 },
  { projectId: 'A30124', projectName: 'Bodily injury claims', client: 'Northstar Insurance', domain: 'Claims', weight: 0.7, pace: 1.08, miss: 1.2 },
  { projectId: 'A30125', projectName: 'Coverage interpretation', client: 'Northstar Insurance', domain: 'Coverage', weight: 0.26, pace: 0.92, miss: 0.65 },
  { projectId: 'A30126', projectName: 'Carrier disputes', client: 'Vanta Logistics', domain: 'Freight', weight: 0.44, pace: 1.18, miss: 1.45 },
  { projectId: 'A30127', projectName: 'Demurrage invoices', client: 'Vanta Logistics', domain: 'Billing', weight: 0.24, pace: 1.0, miss: 0.8 },
  { projectId: 'A30128', projectName: 'Adverse event review', client: 'Lumen Pharma', domain: 'Drug safety', weight: 0.5, pace: 1.38, miss: 1.95 },
  { projectId: 'A30129', projectName: 'Batch record inquiry', client: 'Lumen Pharma', domain: 'Quality', weight: 0.2, pace: 0.88, miss: 0.5 },
  { projectId: 'A30130', projectName: 'Public records requests', client: 'Harbor Civic', domain: 'Public records', weight: 0.34, pace: 1.02, miss: 0.9 },
  { projectId: 'A30131', projectName: 'Workplace investigations', client: 'Harbor Civic', domain: 'Employment', weight: 0.3, pace: 1.24, miss: 1.55 },
  { projectId: 'A30132', projectName: 'Product liability review', client: 'Atlas Manufacturing', domain: 'Product', weight: 0.4, pace: 1.12, miss: 1.3 },
  { projectId: 'A30133', projectName: 'Vendor contract review', client: 'Atlas Manufacturing', domain: 'Supply', weight: 0.18, pace: 0.94, miss: 0.6 },
  { projectId: 'A30134', projectName: 'Customer billing disputes', client: 'Kepler Telecom', domain: 'Customer accounts', weight: 0.42, pace: 0.98, miss: 1.05 },
  { projectId: 'A30135', projectName: 'Network outage claims', client: 'Kepler Telecom', domain: 'Network', weight: 0.16, pace: 1.1, miss: 0.7 },
];

const REGIONS = [
  ['IN', 'India', 1],
  ['UK', 'United Kingdom', 1.15],
  ['EU', 'European Union', 1.2],
  ['US', 'United States', 1.35],
];

const ASSIGNMENTS = [
  'Executive Communications',
  'Engineering and Battery Safety',
  'Financial Reconciliations',
  'Carrier correspondence',
  'Demurrage invoices',
];

const GROUPS = ['First-pass review', 'Privilege review', 'Quality control'];
const QUEUES = ['assigned', 'in_progress', 'completed'];
const SIZES = ['small', 'medium', 'large'];
const KINDS = ['Email', 'Memo', 'Contract', 'Spreadsheet', 'Deposition', 'Invoice', 'Chat', 'Policy'];
const LANGUAGES = ['English', 'English', 'English', 'English', 'Chinese', 'Spanish', 'German'];
const FORMS = ['Responsive', 'Not responsive', 'Privileged', 'Confidential', 'Redact'];

const PAGES = { small: [1, 2], medium: [3, 5, 8], large: [12, 18, 24] };

export function sizeFor(pages) {
  if (pages <= 2) return 'small';
  if (pages <= 8) return 'medium';
  return 'large';
}

export function weightsFor(language, content) {
  return {
    languageWeight: language === 'English' ? 1 : 1.5,
    contentWeight: content === 'dense' ? 1.5 : 1,
  };
}

export function estimateMinutes(pages, languageWeight, contentWeight, regionWeight = 1) {
  return Math.round(pages * languageWeight * contentWeight * regionWeight * 4);
}

function ymd(year, month, day) {
  return `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
}

function months() {
  const list = [];
  for (let year = 2025; year <= 2026; year += 1) {
    const last = year === 2026 ? 9 : 12;
    for (let month = 1; month <= last; month += 1) {
      list.push({ year, month, days: new Date(Date.UTC(year, month, 0)).getUTCDate() });
    }
  }
  return list;
}

function build() {
  const documents = [];
  let seq = 0;
  let n = 0;

  function emit({ date, reviewer, project, queue, size, released = false, checked = false, miss = false, defect = false }) {
    n += 1;
    const pages = PAGES[size][n % PAGES[size].length];
    const language = LANGUAGES[n % LANGUAGES.length];
    const content = size === 'large' || n % 5 === 0 ? 'dense' : 'normal';
    const weights = weightsFor(language, content);
    const [region, regionName, regionWeight] = REGIONS[n % REGIONS.length];
    const estimated = estimateMinutes(pages, weights.languageWeight, weights.contentWeight, regionWeight);
    const pace = reviewer ? reviewer.pace * (project.pace || 1) * (0.94 + (n % 8) / 100) : 1;
    const timed = queue === 'completed';
    const tags = queue === 'unassigned' ? [] : [FORMS[n % FORMS.length]];
    if (queue !== 'unassigned' && n % 4 === 0) tags.push('Confidential');
    if (queue !== 'unassigned' && n % 7 === 0) tags.push('Hot');
    seq += 1;
    const id = `D${String(seq).padStart(5, '0')}`;
    documents.push({
      id,
      projectId: project.projectId,
      projectName: project.projectName,
      client: project.client,
      domain: project.domain,
      region,
      regionName,
      regionWeight,
      assignment: ASSIGNMENTS[n % ASSIGNMENTS.length],
      securityGroup: GROUPS[n % GROUPS.length],
      userId: reviewer ? reviewer.userId : null,
      reviewer: reviewer ? reviewer.reviewer : null,
      queue,
      released: queue === 'completed' && released,
      checked: queue === 'completed' && checked,
      miss: queue === 'completed' && checked && miss,
      defect: queue === 'completed' && checked && miss && defect,
      tags: [...new Set(tags)],
      title: `${KINDS[n % KINDS.length]} ${id}`,
      pages,
      size: sizeFor(pages),
      language,
      timed,
      date,
      content,
      languageWeight: weights.languageWeight,
      contentWeight: weights.contentWeight,
      estimatedMinutes: estimated,
      ...(timed ? { actualMinutes: Math.max(1, Math.round(estimated * pace)) } : {}),
    });
  }

  for (const month of months()) {
    // Q2 and Q3 carry a full review program. Other months stay dense enough to filter.
    const scale = month.year === 2026 && month.month >= 4 && month.month <= 9 ? 5 : 1;
    let cell = 0;
    for (const reviewer of REVIEWERS) {
      for (const project of PROJECTS) {
        for (const queue of QUEUES) {
          for (const size of SIZES) {
            const band = size === 'small' ? reviewer.volume + 2 : size === 'medium' ? reviewer.volume : 1;
            const copies = queue === 'completed' ? Math.max(1, Math.round(band * scale * (project.weight || 1))) : 1;
            for (let copy = 0; copy < copies; copy += 1) {
              const day = 1 + ((cell + copy * 9) % month.days);
              const stamp = cell + copy;
              emit({
                date: ymd(month.year, month.month, day),
                reviewer,
                project,
                queue,
                size,
                released: stamp % 3 === 0,
                checked: stamp % 5 === 0,
                miss: stamp % 100 < Math.min(90, Math.round(reviewer.miss * (project.miss || 1))),
                defect: stamp % 2 === 0,
              });
            }
            cell += 1;
          }
        }
      }
    }
    for (const project of PROJECTS) {
      for (const size of SIZES) {
        emit({ date: ymd(month.year, month.month, 1 + (cell % month.days)), reviewer: null, project, queue: 'unassigned', size });
        emit({ date: ymd(month.year, month.month, 1 + ((cell + 3) % month.days)), reviewer: null, project, queue: 'unassigned', size });
        cell += 1;
      }
    }
  }

  function cover(date) {
    let stamp = 0;
    for (const reviewer of REVIEWERS) {
      for (const project of PROJECTS) {
        for (const queue of QUEUES) {
          for (const size of SIZES) {
            stamp += 1;
            emit({
              date,
              reviewer,
              project,
              queue,
              size,
              released: stamp % 3 === 0,
              checked: stamp % 5 === 0,
              miss: stamp % 100 < Math.min(90, Math.round(reviewer.miss * (project.miss || 1))),
              defect: stamp % 2 === 0,
            });
          }
        }
      }
    }
    for (const project of PROJECTS) {
      for (const size of SIZES) emit({ date, reviewer: null, project, queue: 'unassigned', size });
    }
  }
  cover('2026-09-29');
  cover('2026-09-30');

  return documents;
}

const documents = build();

export const landing = {
  generatedAt: '2026-09-30T00:00:00.000Z',
  catalog: {
    projects: PROJECTS.map(({ projectId, projectName, client, domain }) => ({ projectId, projectName, client, domain })),
    clients: [...new Set(PROJECTS.map((item) => item.client))],
    reviewers: REVIEWERS.map(({ reviewer, userId }) => ({ reviewer, userId })),
    assignments: ASSIGNMENTS,
    securityGroups: GROUPS,
  },
  mechanism: {
    formula: 'pages × language weight × content weight × region weight × 4',
    pageMinutes: 4,
    sizes: [
      { key: 'small', label: 'Small', pages: '1–2 pages' },
      { key: 'medium', label: 'Medium', pages: '3–8 pages' },
      { key: 'large', label: 'Large', pages: '9 or more pages' },
    ],
    weights: [
      ['English', '1'],
      ['Any other language', '1.5'],
      ['Normal content', '1'],
      ['Dense content', '1.5'],
      ['India, the home bench', '1'],
      ['United Kingdom', '1.15'],
      ['European Union', '1.2'],
      ['United States', '1.35'],
    ],
    example: 'A 15-page dense English document from India is 15 × 1 × 1.5 × 1 × 4 = 90 minutes. The same document from the United States is 15 × 1 × 1.5 × 1.35 × 4 = 122 minutes.',
    score: 'The time score is 10 when actual minutes are within the estimate. Otherwise it is 10 × estimated ÷ actual.',
  },
  windows: {
    daily: { label: '30 Sep 2026', previousLabel: '29 Sep 2026', from: '2026-09-30', to: '2026-09-30', previousFrom: '2026-09-29', previousTo: '2026-09-29' },
    weekly: { label: '24–30 Sep 2026', previousLabel: '17–23 Sep 2026', from: '2026-09-24', to: '2026-09-30', previousFrom: '2026-09-17', previousTo: '2026-09-23' },
    monthly: { label: 'September 2026', previousLabel: 'August 2026', from: '2026-09-01', to: '2026-09-30', previousFrom: '2026-08-01', previousTo: '2026-08-31' },
    quarterly: { label: '2026 Q3', previousLabel: '2026 Q2', from: '2026-07-01', to: '2026-09-30', previousFrom: '2026-04-01', previousTo: '2026-06-30' },
    halfYearly: { label: 'Jul–Sep 2026', previousLabel: 'Jan–Jun 2026', from: '2026-07-01', to: '2026-09-30', previousFrom: '2026-01-01', previousTo: '2026-06-30' },
    yearly: { label: '2026 to 30 Sep', previousLabel: '2025', from: '2026-01-01', to: '2026-09-30', previousFrom: '2025-01-01', previousTo: '2025-12-31' },
  },
  documents,
};

export default landing;
