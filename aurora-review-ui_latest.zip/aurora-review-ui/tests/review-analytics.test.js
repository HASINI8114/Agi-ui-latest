import assert from 'node:assert/strict';
import { attachVariance, completionBy, computeMetricsFromDocs, getBand, timeTotals, trendBy } from '../modules/review/src/analytics.js';
import { estimateMinutes, landing, sizeFor } from '../data/review/generate.js';

const doc = (over) => ({
  id: 'D1', projectId: 'A30045', assignment: 'Executive Communications', securityGroup: 'First-pass review',
  reviewer: 'Sarah Jenkins', queue: 'completed', released: true, checked: true, miss: false, defect: false,
  tags: [], title: 'Memo', pages: 1, date: '2026-07-01', timed: true, estimatedMinutes: 10, actualMinutes: 20, ...over,
});

assert.equal(getBand(7), 'very good');
assert.equal(getBand(6), 'good');
assert.equal(getBand(5.9), 'below');

const metrics = computeMetricsFromDocs([doc(), doc({ id: 'D2', miss: true, defect: true, released: false })]);
assert.equal(metrics.completed, 2);
assert.equal(metrics.released, 1);
assert.equal(metrics.defects, 1);
assert.equal(metrics.accuracy, 5);
assert.equal(metrics.revenueUsd, 10);
assert.equal(metrics.savingVersusRelativityUsd, 6);

assert.equal(estimateMinutes(15, 1, 1.5), 90);
assert.equal(estimateMinutes(12, 1, 1.5), 72);
assert.equal(sizeFor(2), 'small');
assert.equal(sizeFor(8), 'medium');
assert.equal(sizeFor(9), 'large');

const gaps = attachVariance([
  { reviewer: 'A', score: 8, completed: 10, accuracy: 9 },
  { reviewer: 'B', score: 6, completed: 4, accuracy: 7 },
]);
assert.equal(gaps[0].scoreGap, 1);
assert.equal(gaps[1].scoreGap, -1);
assert.equal(gaps[0].volumeGap, 3);

const q3 = landing.documents.filter((item) => item.date >= '2026-07-01' && item.date <= '2026-09-30');
for (const name of ['Sarah Jenkins', 'Priya Patel']) {
  for (const queue of ['assigned', 'in_progress', 'completed']) {
    for (const size of ['small', 'medium', 'large']) {
      assert.equal(q3.some((item) => item.reviewer === name && item.queue === queue && item.size === size), true, `${name} ${queue} ${size}`);
    }
  }
}
assert.equal(q3.some((item) => item.title.startsWith('Email')), true);
assert.equal(q3.some((item) => item.queue === 'unassigned' && item.projectId === 'A30048'), true);
const day = landing.documents.filter((item) => item.date === '2026-09-30' && item.reviewer === 'Sarah Jenkins');
assert.equal(day.some((item) => item.queue === 'assigned'), true);
assert.equal(day.some((item) => item.queue === 'completed' && item.size === 'large'), true);
const quarter = computeMetricsFromDocs(q3);
assert.ok(quarter.revenueUsd >= 100000, `quarterly revenue ${quarter.revenueUsd}`);
assert.ok(landing.catalog.reviewers.length >= 20);
const sample = q3.find((item) => item.timed);
assert.equal(sample.estimatedMinutes, estimateMinutes(sample.pages, sample.languageWeight, sample.contentWeight, sample.regionWeight));
assert.equal(sample.size, sizeFor(sample.pages));

for (const item of landing.documents.slice(0, 5000)) {
  assert.equal(item.estimatedMinutes, estimateMinutes(item.pages, item.languageWeight, item.contentWeight, item.regionWeight));
  assert.equal(item.actualMinutes != null, item.queue === 'completed', `${item.id} actual time follows review`);
}
const inWindow = (from, to) => landing.documents.filter((item) => item.date >= from && item.date <= to);
assert.equal(trendBy(inWindow('2026-07-01', '2026-09-30'), (item) => item.client).unit, 'month');
assert.equal(trendBy(inWindow('2026-09-01', '2026-09-30'), (item) => item.client).unit, 'week');
assert.equal(trendBy(inWindow('2026-09-24', '2026-09-30'), (item) => item.client).unit, 'day');
assert.equal(trendBy(inWindow('2026-09-30', '2026-09-30'), (item) => item.client).periods.length, 1);
const totals = timeTotals([doc(), doc({ id: 'D2', queue: 'assigned', timed: false, actualMinutes: undefined })]);
assert.deepEqual(totals, { documents: 2, reviewed: 1, planned: 20, estimated: 10, actual: 20 });

const finished = landing.documents.filter((item) => item.queue === 'completed').length;
for (const unit of ['week', 'month', 'quarter', 'year']) {
  const rows = completionBy(landing.documents, unit, '2026-07-01', '2026-09-30');
  assert.equal(rows.reduce((sum, row) => sum + row.value, 0), finished, unit);
  assert.equal(rows.at(-1).total, finished, unit);
  assert.equal(rows.at(-1).selected, true, unit);
}
assert.deepEqual(completionBy(landing.documents, 'year', '2026-07-01', '2026-09-30').map((row) => row.label), ['2025', '2026']);
assert.equal(completionBy(landing.documents, 'quarter', '2026-07-01', '2026-09-30').filter((row) => row.selected).length, 1);
assert.equal(completionBy(landing.documents, 'month', '2026-07-01', '2026-09-30').filter((row) => row.selected).length, 3);
