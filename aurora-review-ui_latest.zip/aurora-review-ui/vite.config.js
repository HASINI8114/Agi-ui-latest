import { resolve } from 'node:path';
import { viteSingleFile } from 'vite-plugin-singlefile';
const r = (p) => resolve(import.meta.dirname, p);
const ui = (n, f) => ({ find: `@siloverse/ui/${n}`, replacement: r(`packages/ui/${f}`) });
export default {
  root: r('modules/review'), base: './',
  plugins: [viteSingleFile()],
  resolve: { dedupe:['react','react-dom'], alias: [
    { find: '@siloverse/services', replacement: r('local-services.js') },
    ui('accents.css','accents.css'), ui('sections.css','sections.css'), ui('tokens.css','tokens.css'),
    ui('charts','charts.jsx'), ui('sections','sections.js'), ui('primitives','ui.jsx'), ui('query','query.jsx'), ui('session','session.js'),
  ]},
  server: { fs: { allow: [r('.')] } },
  build: { outDir: r('dist'), emptyOutDir: true, assetsInlineLimit: 1e8, chunkSizeWarningLimit: 1e5 },
};
