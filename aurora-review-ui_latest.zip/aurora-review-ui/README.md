# Aurora Review UI

Standalone copy of the Aurora review analytics UI with synthetic data.

Requires Node.js 20.19 or newer.

    npm install
    npm run dev

Open the address Vite prints. `npm run build` creates one self-contained `dist/index.html`. `npm test` runs the analytics tests.

`local-services.js` stands in for `@siloverse/services`: it skips login and loads `data/review/generate.js`.
`packages/ui` is copied from sgi-web-demo. Replace both to run this inside the real workspace.
