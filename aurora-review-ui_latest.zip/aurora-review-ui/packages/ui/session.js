// Module pages render only for a signed-in user (see sessionService). Opened on its own, a module page sends the browser
// to the shared Silo login; inside the shell, the shell has already checked, so this only catches a session that
// expired before a module's frame opened, and then signs in the whole shell window.
import { sessionService } from '@siloverse/services';

/** Calls `render` when the page may show; otherwise the browser is already on its way to the login page. @param {() => void} render */
export function renderWhenSignedIn(render) {
  if (sessionService.ensure()) render();
}
