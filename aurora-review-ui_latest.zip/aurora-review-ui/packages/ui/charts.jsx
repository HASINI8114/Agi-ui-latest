// Shared charts. Shape, weight and opacity carry state; muted colour marks business type.
import React, { useLayoutEffect, useMemo, useRef, useState } from "react";
import { percent } from "./lib.js";
import { initials, useTip } from "./ui.jsx";

// Charts draw at their real width, so text stays at its true size.
/** @returns {[React.RefObject<HTMLDivElement>, number]} */
function useWidth(fallback = 900) {
  const ref = useRef(null);
  const [w, setW] = useState(fallback);
  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    const ro = new ResizeObserver(([e]) => setW(Math.max(280, Math.round(e.contentRect.width))));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  return [ref, w];
}

// --- Ring: share of a whole -------------------------------------------------------------------------
export function Ring({ parts, size = 168, stroke = 14, center = undefined, label }) {
  const total = parts.reduce((t, p) => t + p.value, 0) || 1;
  const r = (size - stroke) / 2, c = 2 * Math.PI * r;
  let offset = 0;
  return (
    <figure className="ring" style={{ width: size }}>
      <svg viewBox={`0 0 ${size} ${size}`} role="img" aria-label={label}>
        <circle cx={size / 2} cy={size / 2} r={r} className="ring__track" strokeWidth={stroke} />
        {parts.map((p, k) => {
          const len = (p.value / total) * c;
          const el = (
            <circle key={p.label} cx={size / 2} cy={size / 2} r={r} strokeWidth={stroke} className={`ring__part ring__part--${k}`}
              strokeDasharray={`${Math.max(0, len - 3)} ${c}`} strokeDashoffset={-offset} style={{ "--len": len, "--c": c, "--k": k, stroke: p.color }}
              transform={`rotate(-90 ${size / 2} ${size / 2})`}>
              <title>{`${p.label}: ${p.value}`}</title>
            </circle>
          );
          offset += len;
          return el;
        })}
      </svg>
      {center && <figcaption className="ring__center">{center}</figcaption>}
    </figure>
  );
}

// --- Stack: one bar split into parts, with a legend -----------------------------------------------
export function Stack({ parts, onPick = undefined, label = undefined }) {
  const total = parts.reduce((t, p) => t + p.value, 0) || 1;
  return (
    <div className="stack">
      <div className="stack__bar" role="img" aria-label={label || parts.map((p) => `${p.label} ${p.value}`).join(", ")}>
        {parts.filter((p) => p.value).map((p, k) => <span key={p.label} style={{ flexGrow: p.value, "--c": p.color, "--k": k }} title={`${p.label}: ${p.value}`} />)}
      </div>
      <ul className="stack__legend">
        {parts.map((p) => (
          <li key={p.label}>
            <button type="button" onClick={() => onPick?.(p)} disabled={!onPick}><i style={{ "--c": p.color }} />{p.label}<b>{p.value}</b><small>{percent(p.value / total)}</small></button>
          </li>
        ))}
      </ul>
    </div>
  );
}

// --- Bubble map: two measures on log scales, one bubble per company -------------------------------
const ticksFor = (lo, hi) => { const t = []; for (let e = Math.floor(Math.log10(lo)); e <= Math.ceil(Math.log10(hi)); e++) for (const m of [1, 3]) { const v = m * 10 ** e; if (v >= lo * 0.98 && v <= hi * 1.02) t.push(v); } return t; };
export function Bubble({ points, x, y, height = 380, onPick, linearX = false }) {
  const tip = useTip();
  const [ref, W] = useWidth();
  const H = height, P = { l: 58, r: 24, t: 22, b: 40 };
  // Log scales need positive x/y. Scraped rows often have 0/null employees or revenue — keep them out so Overview does not blank the app.
  const plotted = linearX
    ? points.filter((p) => Number.isFinite(p.x) && Number.isFinite(p.y))
    : points.filter((p) => p.x > 0 && p.y > 0);
  if (!plotted.length) {
    return <div className="chart chart--empty" ref={ref} role="status" style={{ height }}>No companies with both {x.label.toLowerCase()} and {y.label.toLowerCase()} to plot.</div>;
  }
  const xs = plotted.map((p) => p.x), ys = plotted.map((p) => p.y);
  const [x0, x1] = linearX ? [Math.min(0, ...xs), Math.max(...xs) * 1.1 || 1] : [Math.min(...xs) / 1.6, Math.max(...xs) * 1.6];
  const [y0, y1] = [Math.min(...ys) / 1.6, Math.max(...ys) * 1.6];
  const lx = (v) => P.l + (linearX ? (v - x0) / (x1 - x0 || 1) : Math.log(v / x0) / Math.log(x1 / x0)) * (W - P.l - P.r);
  const ly = (v) => H - P.b - (Math.log(v / y0) / Math.log(y1 / y0)) * (H - P.t - P.b);
  const xt = linearX ? [x0, (x0 + x1) / 2, x1].map((v) => Math.round(v * 100) / 100) : ticksFor(x0, x1);
  const maxR = Math.max(...plotted.map((p) => p.r || 1));
  const scale = Math.min(1, W / 900);
  return (
    <div className="chart" ref={ref}>
      <svg viewBox={`0 0 ${W} ${H}`} className="bubble" role="group" aria-label={`${y.label} against ${x.label}`}>
        {ticksFor(y0, y1).map((v) => <g key={`y${v}`}><line x1={P.l} x2={W - P.r} y1={ly(v)} y2={ly(v)} className="grid" /><text x={P.l - 8} y={ly(v) + 4} textAnchor="end" className="axis">{y.format(v)}</text></g>)}
        {xt.map((v) => <text key={`x${v}`} x={lx(v)} y={H - 16} textAnchor="middle" className="axis">{x.format(v)}</text>)}
        <text x={W - P.r} y={H - 2} textAnchor="end" className="axis axis--title">{x.label} →</text>
        <text x={P.l} y={P.t - 4} className="axis axis--title">↑ {y.label}</text>
        {[...plotted].sort((a, b) => (b.r || 1) - (a.r || 1)).map((p, k) => {
          const r = (8 + Math.sqrt((p.r || 1) / maxR) * 24) * (0.7 + 0.3 * scale);
          return (
            <g key={p.key} className={`bubble__dot ${p.self ? "is-self" : ""} ${p.dim ? "is-dim" : ""}`} transform={`translate(${lx(p.x)} ${ly(p.y)})`} style={{ "--c": p.color, "--k": k }}
              onMouseMove={(e) => tip.show(e, p.tip)} onMouseLeave={tip.hide} onClick={() => onPick?.(p.key)} tabIndex={0} role="button" aria-label={p.label}
              onKeyDown={(e) => { if (e.key === "Enter") onPick?.(p.key); }}>
              <circle r={r} />
              {r > 17 && <text textAnchor="middle" dy="4">{p.self ? "C·" : initials(p.label)}</text>}
            </g>
          );
        })}
      </svg>
      {tip.node}
    </div>
  );
}

// --- Slope: each company's value across periods, on a linear scale -------------------------------
export function Slope({ series, periods, format, height = 340, onPick, axis = format }) {
  const tip = useTip();
  const [ref, W] = useWidth();
  // Extra left/bottom room so first/last FY tick labels are not clipped by a rounded card edge.
  const H = height, P = { l: 56, r: Math.min(200, Math.max(120, W * 0.28)), t: 14, b: 36 };
  const span = Math.max(1, periods.length - 1);
  const plotted = series.map((s) => ({
    ...s,
    values: periods.map((_, i) => {
      const v = s.values[i];
      return Number.isFinite(v) ? v : null;
    }),
  })).filter((s) => s.values.filter((v) => v != null).length >= 2);
  const all = plotted.flatMap((s) => s.values.filter((v) => v != null));
  if (periods.length < 2 || !all.length) {
    return (
      <div className="chart chart--empty" ref={ref} role="status" style={{ height }}>
        Need at least two reporting years with comparable figures to plot growth.
      </div>
    );
  }
  const lo = Math.min(...all), hi = Math.max(...all), pad = (hi - lo) * 0.06 || 1;
  const lx = (i) => P.l + (i / span) * (W - P.l - P.r);
  const ly = (v) => H - P.b - ((v - lo + pad) / (hi - lo + 2 * pad)) * (H - P.t - P.b);
  const end = (s) => {
    for (let i = s.values.length - 1; i >= 0; i--) if (s.values[i] != null) return s.values[i];
    return null;
  };
  // End labels for the leaders and Consilio, nudged apart so they never overlap.
  const chosen = [...plotted].sort((a, b) => end(b) - end(a)).filter((s, i, arr) => i < 4 || i >= arr.length - 2 || s.self);
  const labels = chosen.map((s) => ({ s, y: ly(end(s)) })).sort((a, b) => a.y - b.y);
  for (let i = 1; i < labels.length; i++) labels[i].y = Math.max(labels[i].y, labels[i - 1].y + 16);
  for (let i = labels.length - 2; i >= 0; i--) labels[i].y = Math.min(labels[i].y, labels[i + 1].y - 16, H - P.b);
  const ticks = [lo, (lo + hi) / 2, hi];
  const last = periods.length - 1;
  return (
    <div className="chart" ref={ref}>
      <svg viewBox={`0 0 ${W} ${H}`} className="slope" role="group" aria-label={`Change across ${periods.join(", ")}`}>
        {ticks.map((v) => <g key={v}><line x1={P.l} x2={lx(last)} y1={ly(v)} y2={ly(v)} className="grid" /><text x={P.l - 8} y={ly(v) + 4} textAnchor="end" className="axis">{axis(v)}</text></g>)}
        {periods.map((p, i) => <text key={p} x={lx(i)} y={H - 10} textAnchor={i === 0 ? "start" : i === last ? "end" : "middle"} className="axis">{p}</text>)}
        {plotted.map((s, k) => {
          const pts = s.values.map((v, i) => (v == null ? null : [lx(i), ly(v)])).filter(Boolean);
          if (pts.length < 2) return null;
          return (
            <g key={s.key} className={`slope__line ${s.self ? "is-self" : ""}`} style={{ "--c": s.color, "--k": k }}
              onMouseMove={(e) => tip.show(e, <><b>{s.label}</b><span>{s.values.filter((v) => v != null).map(format).join(" → ")}</span></>)} onMouseLeave={tip.hide} onClick={() => onPick?.(s.key)}>
              <path d={pts.map((p, i) => `${i ? "L" : "M"}${p[0]},${p[1]}`).join("")} pathLength="1" />
              {pts.map((p, i) => <circle key={i} cx={p[0]} cy={p[1]} r={s.self ? 5 : 3.5} />)}
            </g>
          );
        })}
        {labels.map(({ s, y }) => {
          const e = end(s);
          return (
            <g key={`l${s.key}`} className={`slope__label ${s.self ? "is-self" : ""}`}>
              <line x1={lx(last) + 6} x2={lx(last) + 14} y1={ly(e)} y2={y} />
              <text x={lx(last) + 18} y={y + 4}>{s.label} · {format(e)}</text>
            </g>
          );
        })}
      </svg>
      {tip.node}
    </div>
  );
}

// --- Spark: three points in a word's width -------------------------------------------------------
export function Spark({ values, width = 64, height = 22 }) {
  const v = values.filter((x) => x != null);
  if (v.length < 2) return null;
  const lo = Math.min(...v), hi = Math.max(...v), span = hi - lo || 1;
  const pts = v.map((x, i) => [2 + (i / (v.length - 1)) * (width - 4), height - 3 - ((x - lo) / span) * (height - 6)]);
  return (
    <svg className="spark" width={width} height={height} viewBox={`0 0 ${width} ${height}`} aria-hidden="true">
      <path d={pts.map((p, i) => `${i ? "L" : "M"}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join("")} pathLength="1" />
      <circle cx={pts.at(-1)[0]} cy={pts.at(-1)[1]} r="2.4" />
    </svg>
  );
}

// --- Treemap: each company sized by a measure ---------------------------------------------------
function squarify(items, x, y, w, h) {
  const out = [];
  const total = items.reduce((t, i) => t + i.value, 0);
  let rest = items.map((i) => ({ ...i, area: (i.value / total) * w * h }));
  const worst = (row, side) => { const s = row.reduce((t, i) => t + i.area, 0), mx = Math.max(...row.map((i) => i.area)), mn = Math.min(...row.map((i) => i.area)); return Math.max((side * side * mx) / (s * s), (s * s) / (side * side * mn)); };
  while (rest.length) {
    const short = Math.min(w, h);
    let row = [rest[0]], best = worst(row, short);
    for (let k = 1; k < rest.length; k++) { const next = [...row, rest[k]], s = worst(next, short); if (s > best) break; row = next; best = s; }
    const thick = row.reduce((t, i) => t + i.area, 0) / short;
    let pos = 0;
    for (const it of row) { const len = it.area / thick; out.push(w >= h ? { ...it, x, y: y + pos, w: thick, h: len } : { ...it, x: x + pos, y, w: len, h: thick }); pos += len; }
    if (w >= h) { x += thick; w -= thick; } else { y += thick; h -= thick; }
    rest = rest.slice(row.length);
  }
  return out;
}
export function Treemap({ items, format, height = 300 }) {
  const tip = useTip();
  const W = 1000, H = height * 2;
  const tiles = useMemo(() => squarify(items.filter((i) => i.value > 0), 0, 0, W, H), [items, H]);
  return (
    <div className="chart treemap" style={{ aspectRatio: `${W} / ${H}` }}>
      {tiles.map((t, k) => {
        const big = t.w > 150 && t.h > 90;
        return (
          <a key={t.key} href={t.href} className={`treemap__tile ${big ? "is-big" : ""} ${t.self ? "is-self" : ""}`} data-open={t.key}
            style={{ left: `${(t.x / W) * 100}%`, top: `${(t.y / H) * 100}%`, width: `${(t.w / W) * 100}%`, height: `${(t.h / H) * 100}%`, "--c": t.color, "--k": k }}
            onMouseMove={(e) => tip.show(e, <><b>{t.label}</b><span>{format(t.value)}</span></>)} onMouseLeave={tip.hide} aria-label={`${t.label}, ${format(t.value)}`}>
            {t.w > 60 && t.h > 34 && <span className="treemap__name">{t.label}</span>}
            {big && <span className="treemap__value">{format(t.value)}</span>}
          </a>
        );
      })}
      {tip.node}
    </div>
  );
}

// --- Heatmap: counts or shares in a grid; each cell can open its companies --------------------------
// Two shade bands keep every label readable: strong cells read dark-on-light, faint ones light-on-dark.
const shade = (v) => (!v ? 0 : v >= 0.5 ? 0.65 + (v - 0.5) * 0.7 : 0.08 + v * 0.48);
export function Heatmap({ rows, columns, onPick = undefined, selected = undefined, corner = "", format = (c) => c.label, className = "", fill = false }) {
  return (
    <div className={`heat ${className} ${fill ? "heat--fill" : ""}`} style={{ "--cols": columns.length, gridTemplateRows: fill ? `auto repeat(${rows.length}, minmax(32px, 1fr))` : undefined }} role="table">
      <div className="heat__row heat__row--head" role="row">
        <span role="columnheader" className="heat__corner">{corner}</span>
        {columns.map((c) => <span role="columnheader" key={c.key} className="heat__col" title={c.label}>{c.short || c.label}</span>)}
      </div>
      {rows.map((r, ri) => (
        <div className="heat__row" role="row" key={r.key}>
          <span role="rowheader" className="heat__name">{r.label}{r.note && <small>{r.note}</small>}</span>
          {r.cells.map((cell, ci) => {
            const on = selected && selected.row === r.key && selected.col === columns[ci].key;
            return (
              <span role="cell" key={ci}>
                <button type="button" className={`heat__cell ${on ? "is-on" : ""} ${cell.v >= 0.5 ? "is-dark" : ""}`} style={{ "--p": shade(cell.v), "--k": ri + ci }}
                  aria-label={`${r.label}, ${columns[ci].label}: ${cell.aria ?? cell.label}`} aria-pressed={on} onClick={() => onPick?.(r.key, columns[ci].key)}>
                  {cell.empty ? <small>—</small> : format(cell)}
                </button>
              </span>
            );
          })}
        </div>
      ))}
    </div>
  );
}

// --- Columns: values over a short axis -------------------------------------------------------------
export function Columns({ items, height = 150, onPick = undefined, selected = undefined }) {
  const max = Math.max(...items.map((i) => i.value), 1);
  return (
    <div className="cols" style={{ "--h": `${height}px` }}>
      {items.map((it, k) => (
        <button type="button" key={it.key} className={`cols__item ${selected === it.key ? "is-on" : ""}`} onClick={() => onPick?.(it.key)} title={`${it.label}: ${it.value}`} aria-pressed={selected === it.key}>
          <span className="cols__n">{it.value || ""}</span>
          <i style={{ "--v": it.value / max, "--k": k }} />
          <span className="cols__label">{it.short}</span>
        </button>
      ))}
    </div>
  );
}
