// Lifetime for the existing DOM interactions while their sections migrate to JSX.
export function browserScope() {
  const controller = new AbortController(), timers = new Set(), frames = new Set(), observers = new Set();
  const listen = (target) => (type, listener, options = {}) => target.addEventListener(type, listener, { ...options, signal: controller.signal });
  return {
    addEventListener: listen(window),
    onDocument: listen(document),
    setTimeout(callback, delay) {
      const id = window.setTimeout(() => { timers.delete(id); callback(); }, delay);
      timers.add(id);
      return id;
    },
    requestAnimationFrame(callback) {
      const id = window.requestAnimationFrame((time) => { frames.delete(id); callback(time); });
      frames.add(id);
      return id;
    },
    IntersectionObserver: class extends window.IntersectionObserver {
      constructor(callback, options) { super(callback, options); observers.add(this); }
    },
    dispose() {
      controller.abort();
      timers.forEach((id) => clearTimeout(id));
      frames.forEach((id) => cancelAnimationFrame(id));
      observers.forEach((observer) => observer.disconnect());
    },
  };
}
