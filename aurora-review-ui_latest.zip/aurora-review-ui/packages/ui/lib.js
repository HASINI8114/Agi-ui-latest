export const number = (value) => value == null ? "—" : new Intl.NumberFormat("en-US").format(value);
export const percent = (value, digits = 0) => (value == null ? "—" : `${(value * 100).toFixed(digits)}%`);
export const plural = (n, word, many = `${word}s`) => `${n} ${n === 1 ? word : many}`;
// Target durations in minutes, read the way people say them.
export function duration(minutes) {
  if (minutes == null) return "—";
  if (minutes === 0) return "Immediate";
  if (minutes < 60) return `${minutes} min`;
  if (minutes < 1440) { const h = +(minutes / 60).toFixed(1); return `${h} ${h === 1 ? "hour" : "hours"}`; }
  const d = +(minutes / 1440).toFixed(1);
  return `${d} ${d === 1 ? "day" : "days"}`;
}
const cell = (value) => `"${String(value ?? "").replace(/^[=+@\-\t\r]/, "'$&").replaceAll('"', '""')}"`;
export const toCsv = (rows) => rows.map((r) => r.map(cell).join(",")).join("\r\n");
