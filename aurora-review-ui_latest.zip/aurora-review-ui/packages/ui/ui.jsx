// Shared building blocks: icons, figures, controls and motion helpers.
import React, { useEffect, useLayoutEffect, useRef, useState } from "react";
import { percent } from "./lib.js";

const paths = {
  search: "m21 21-5-5 M19 11a8 8 0 1 1-16 0 8 8 0 0 1 16 0",
  arrow: "M5 12h14 m-5-5 5 5-5 5",
  back: "M19 12H5 m5-5-5 5 5 5",
  up: "M12 19V5 m-6 6 6-6 6 6",
  down: "M12 5v14 m-6-6 6 6 6-6",
  chevron: "m8 10 4 4 4-4",
  left: "m14 6-6 6 6 6",
  right: "m10 6 6 6-6 6",
  download: "M12 3v12 m-4-4 4 4 4-4 M5 16v4h14v-4",
  sun: "M12 2v2 M12 20v2 M2 12h2 M20 12h2 M5 5l1.5 1.5 M17.5 17.5 1.5 1.5 M5 19l1.5-1.5 M17.5 6.5 1.5-1.5 M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0",
  moon: "M20.5 14A9 9 0 0 1 10 3.5 9 9 0 1 0 20.5 14",
  star: "m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9Z",
  grid: "M3 3h7v7H3Z M14 3h7v7h-7Z M3 14h7v7H3Z M14 14h7v7h-7Z",
  list: "M8 5h13 M8 12h13 M8 19h13 M3 5h.01 M3 12h.01 M3 19h.01",
  close: "m6 6 12 12 M6 18 18 6",
  check: "m5 12 4 4L19 6",
  plus: "M12 5v14 M5 12h14",
  minus: "M5 12h14",
  spark: "M12 3v4 M12 17v4 M3 12h4 M17 12h4 M6 6l2.5 2.5 M15.5 15.5 18 18 M6 18l2.5-2.5 M15.5 8.5 18 6",
  send: "M4 12 20 4l-6 16-3-7Z M11 13l9-9",
  filter: "M3 5h18 M6 12h12 M10 19h4",
  reset: "M4 4v6h6 M4.5 15a8 8 0 1 0 1.9-8.3L4 10",
  play: "M7 4.5v15l12-7.5Z",
  pause: "M7 4h3.5v16H7Z M13.5 4H17v16h-3.5Z",
  prev: "M6 5v14 M19 5 9 12l10 7Z",
  next: "M18 5v14 M5 5l10 7-10 7Z",
  stop: "M6 6h12v12H6Z",
  fit: "M4 9V4h5 M20 9V4h-5 M4 15v5h5 M20 15v5h-5",
  expand: "M14 4h6v6 M10 20H4v-6 M20 4l-7 7 M4 20l7-7",
  shrink: "M4 14h6v6 M20 10h-6V4 M10 14l-7 7 M14 10l7-7",
  clock: "M12 7v5l3 2 M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0",
  tool: "M14.7 6.3a4 4 0 0 0-5.4 5.2L3.5 17.3a1.4 1.4 0 0 0 2 2l5.8-5.8a4 4 0 0 0 5.2-5.4l-2.4 2.4-2.1-.5-.5-2.1Z",
  hand: "M8 13V5.5a1.5 1.5 0 0 1 3 0V11 M11 10V4.5a1.5 1.5 0 0 1 3 0V11 M14 10.5V6a1.5 1.5 0 0 1 3 0v7a7 7 0 0 1-7 7h-.5a6 6 0 0 1-4.6-2.2L3.5 15a1.5 1.5 0 0 1 2.3-2L8 15",
  users: "M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8 M2 21v-1a6 6 0 0 1 12 0v1 M16 3.1a4 4 0 0 1 0 7.8 M22 21v-1a6 6 0 0 0-4-5.7",
  flow: "M4 6h6v4H4Z M14 14h6v4h-6Z M7 10v4a2 2 0 0 0 2 2h5",
  link: "M14 4h6v6 M20 4l-9 9 M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5",
  target: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18 M12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8 M12 12h.01",
  route: "M6 19a2 2 0 1 0 0-4 2 2 0 0 0 0 4 M18 9a2 2 0 1 0 0-4 2 2 0 0 0 0 4 M6 15V9a4 4 0 0 1 4-4h6 M8 17h6a4 4 0 0 0 4-4V9",
};
export function Icon({ name, size = 18, className = "" }) {
  return (
    <svg className={`icon ${className}`} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d={paths[name] || paths.arrow} />
    </svg>
  );
}

export const initials = (name) => name.split(/\s+/).filter((w) => !["and", "of", "the"].includes(w.toLowerCase())).slice(0, 2).map((w) => w[0]).join("");

// A role's monogram, tinted by its department.
export function RoleMark({ role, size = "sm", tone }) {
  if (!role) return null;
  return <span className={`mark mark--${size}`} style={{ "--c": tone }} title={role.RoleName} aria-hidden="true">{initials(role.RoleName.replace(/\(.*\)/, ""))}</span>;
}

// One glyph per step type, so shape (not colour) tells a decision from a process.
const TYPE_GLYPH = {
  Start: <path d="M8 6v12l10-6Z" />, Process: <rect x="6" y="6" width="12" height="12" rx="2.5" />,
  Condition: <path d="M12 4.5 19.5 12 12 19.5 4.5 12Z" />, Output: <><rect x="5" y="6" width="10" height="12" rx="2" /><path d="M15 12h5 m-2-2 2 2-2 2" /></>,
  Stop: <circle cx="12" cy="12" r="6.5" />, Loop: <path d="M18 9a6.5 6.5 0 1 0 .8 5 M18.5 4.5V9H14" />,
};
export function TypeGlyph({ type, size = 16 }) {
  return <svg className={`tglyph tglyph--${(type || "Process").toLowerCase()}`} width={size} height={size} viewBox="0 0 24 24" aria-hidden="true">{TYPE_GLYPH[type] || TYPE_GLYPH.Process}</svg>;
}

export function Delta({ value, suffix = "" }) {
  if (value == null) return <span className="delta delta--none">New</span>;
  const dir = value > 0.005 ? "up" : value < -0.005 ? "down" : "flat";
  return (
    <span className={`delta delta--${dir}`} title={`${percent(value)} on last year${suffix}`}>
      {dir !== "flat" && <Icon name={dir} size={12} />}
      {dir === "flat" ? "Flat" : percent(Math.abs(value), Math.abs(value) >= 10 ? 0 : 1)}
    </span>
  );
}

// Numbers count up once when they first appear.
const reduced = () => typeof matchMedia === "function" && matchMedia("(prefers-reduced-motion: reduce)").matches;
export function CountUp({ value, format = (v) => Math.round(v).toLocaleString("en-US"), duration = 1100 }) {
  const [shown, setShown] = useState(reduced() ? value : 0);
  const from = useRef(0);
  useEffect(() => {
    if (reduced()) { setShown(value); return; }
    let raf, start;
    const a = from.current, b = value;
    const step = (t) => {
      start ??= t;
      const k = Math.min(1, (t - start) / duration);
      const e = 1 - Math.pow(1 - k, 4);
      setShown(a + (b - a) * e);
      if (k < 1) raf = requestAnimationFrame(step); else from.current = b;
    };
    raf = requestAnimationFrame(step);
    return () => { cancelAnimationFrame(raf); from.current = b; };
  }, [value, duration]);
  return <span className="figure"><span className="sr-only">{format(value)}</span><span aria-hidden="true">{format(shown)}</span></span>;
}

// A pill segmented control whose highlight slides to the chosen option.
export function Seg({ options, value, onChange, label, size = "md", className = "" }) {
  const ref = useRef(null);
  const [thumb, setThumb] = useState(null);
  useLayoutEffect(() => {
    const measure = () => {
      const el = ref.current?.querySelector('[aria-pressed="true"]');
      if (el) setThumb({ left: el.offsetLeft, width: el.offsetWidth, top: el.offsetTop, height: el.offsetHeight });
    };
    measure();
    const ro = new ResizeObserver(measure);
    if (ref.current) ro.observe(ref.current);
    return () => ro.disconnect();
  }, [value, options.length]);
  return (
    <div className={`seg seg--${size} ${className}`} role="group" aria-label={label} ref={ref}>
      {thumb && <span className="seg__thumb" style={{ transform: `translate(${thumb.left}px, ${thumb.top}px)`, width: thumb.width, height: thumb.height }} aria-hidden="true" />}
      {options.map((o) => {
        const [key, text, count] = Array.isArray(o) ? o : [o, o];
        return (
          <button key={key} type="button" className="seg__btn" aria-pressed={key === value} onClick={() => onChange(key)}>
            {text}{count != null && <span>{count}</span>}
          </button>
        );
      })}
    </div>
  );
}

export function Select({ label, value, options, onChange, hideLabel = false }) {
  return (
    <label className="select">
      <span className={hideLabel ? "sr-only" : "select__label"}>{label}</span>
      <span className="select__box">
        <select value={value} onChange={(e) => onChange(e.target.value)}>
          {options.map((o) => {
            const [key, text] = Array.isArray(o) ? o : [o, o];
            return <option key={key} value={key}>{text}</option>;
          })}
        </select>
        <Icon name="chevron" size={14} />
      </span>
    </label>
  );
}

/** @param {{title?: React.ReactNode, sub?: React.ReactNode, action?: React.ReactNode, children?: React.ReactNode, className?: string, i?: number, as?: React.ElementType, [key: string]: any}} props */
export function Panel({ title, sub, action, children, className = "", i = 0, as: Tag = "section", ...rest }) {
  return (
    <Tag className={`panel rise ${className}`} style={{ "--i": i }} {...rest}>
      {(title || action) && (
        <header className="panel__head">
          <div>
            {title && <h2 className="panel__title">{title}</h2>}
            {sub && <p className="panel__sub">{sub}</p>}
          </div>
          {action}
        </header>
      )}
      {children}
    </Tag>
  );
}

// Horizontal bars that fill in; each row may link somewhere.
export function Bars({ items, max = undefined, format = (v, _item = undefined) => v.toLocaleString("en-US"), className = "" }) {
  const top = max ?? Math.max(...items.map((i) => i.value), 0);
  return (
    <ul className={`bars ${className}`}>
      {items.map((it, k) => {
        const inner = (
          <>
            <span className="bars__label">{it.label}{it.note && <small>{it.note}</small>}</span>
            <span className="bars__track"><i style={{ "--v": top ? it.value / top : 0, "--k": k }} /></span>
            <span className="bars__value">{format(it.value, it)}</span>
          </>
        );
        return (
          <li key={it.key ?? it.label}>
            {it.href ? <a className="bars__row" href={it.href}>{inner}</a> : it.onClick ? <button type="button" className="bars__row" onClick={it.onClick}>{inner}</button> : <div className="bars__row">{inner}</div>}
          </li>
        );
      })}
    </ul>
  );
}

export function Split({ parts, label }) {
  const total = parts.reduce((t, p) => t + p.value, 0);
  return (
    <div className="split" role="img" aria-label={label || parts.map((p) => `${p.label} ${p.value}`).join(", ")}>
      {parts.filter((p) => p.value).map((p, k) => (
        <span key={p.label} className={`split__seg split__seg--${k}`} style={{ flexGrow: p.value / total, "--k": k }} title={`${p.label}: ${p.value}`} />
      ))}
    </div>
  );
}

export function Empty({ title, text = undefined, action = undefined }) {
  return (
    <div className="empty">
      <p className="empty__title">{title}</p>
      {text && <p className="empty__text">{text}</p>}
      {action}
    </div>
  );
}

export function readStorage(key, fallback) {
  try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; }
}
export function writeStorage(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); return true; } catch { return false; }
}

export function download(name, text, type = "text/csv;charset=utf-8") {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const a = Object.assign(document.createElement("a"), { href: url, download: name });
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

// Shared floating tooltip for charts.
export function useTip() {
  const [tip, setTip] = useState(null);
  const show = (e, content) => {
    const host = e.currentTarget.closest(".chart");
    const r = host.getBoundingClientRect();
    setTip({ x: e.clientX - r.left, y: e.clientY - r.top, content, w: r.width });
  };
  const node = tip && (
    <div className="tip" style={{ left: Math.min(Math.max(tip.x, 90), tip.w - 90), top: tip.y }} role="presentation">{tip.content}</div>
  );
  return { show, hide: () => setTip(null), node };
}
