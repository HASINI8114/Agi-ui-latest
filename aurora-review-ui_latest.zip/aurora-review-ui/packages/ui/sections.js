import { useEffect, useLayoutEffect, useRef, useState } from 'react';

// One continuous page per module (styles: ./sections.css, imported next to each module's own styles): every section is mounted as `[data-section="<key>"]`, in order.
// Scrolling makes the section under the reading line active (pill, address and, through the shell's embed script, the rail).
// A pill, rail item or deep link scrolls smoothly to its section; while that scroll runs the active section is held on the
// target, so the pills and rail do not tick through every section in between.
//   keys:  section keys in page order
//   keyOf: hash → section key, or null when the hash is not a plain section address (a profile, an editor route…)
//   hashOf: section key → the hash to show while it is in view
//   ready: the sections are rendered (data loaded); a deep link scrolls once this turns true
//   hash:  the address to start from (for server rendering, where there is no location)
//   baseOf: hash → the section a page opened at a non-section address (a profile link) sits on; defaults to keyOf
const motion = () => (matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth');
const sectionEl = (key) => document.querySelector(`[data-section="${CSS.escape(key)}"]`);
// Layout position, not getBoundingClientRect: a section still rising into place is transformed and would read as lower.
const pageTop = (el) => { let y = 0; for (let n = el; n instanceof HTMLElement; n = n.offsetParent) y += n.offsetTop; return y; };

export function useSectionScroll({ keys, keyOf, hashOf, baseOf = keyOf, ready = true, hash = typeof location === 'undefined' ? '' : location.hash }) {
  const [active, setActive] = useState(() => baseOf(hash) ?? keys[0]);
  const held = useRef(null), fns = useRef({ keys, keyOf, hashOf });
  fns.current = { keys, keyOf, hashOf };
  const activeRef = useRef(active);
  activeRef.current = active;
  // The section the address named when this hook last read or wrote it.
  const addressKey = useRef(keyOf(hash));

  function scrollToSection(key, behavior) {
    const el = sectionEl(key);
    if (!el) return;
    held.current = key;
    setActive(key);
    el.scrollIntoView({ behavior, block: 'start' });
    // Held until the scroll really ends (a long smooth scroll can take ~2s), or at once if the user takes over.
    const events = ['scrollend', 'wheel', 'touchstart', 'keydown'];
    const release = () => { if (held.current === key) held.current = null; events.forEach((t) => removeEventListener(t, release)); clearTimeout(timer); };
    const timer = setTimeout(release, behavior === 'smooth' ? 3000 : 80);
    events.forEach((t) => addEventListener(t, release, { passive: true }));
  }

  // The reading line sits just under the sticky pill bar; the last section wins at the very bottom of the page.
  useEffect(() => {
    if (!ready) return;
    let frame = 0;
    const measure = () => {
      frame = 0;
      if (held.current) return;
      const { keys } = fns.current, line = innerHeight * 0.35;
      let next = keys[0];
      if (scrollY + innerHeight >= document.documentElement.scrollHeight - 2) next = keys.at(-1);
      else for (const key of keys) { const el = sectionEl(key); if (el && pageTop(el) - scrollY <= line) next = key; }
      if (next !== activeRef.current) setActive(next);
    };
    const onScroll = () => { if (!frame) frame = requestAnimationFrame(measure); };
    addEventListener('scroll', onScroll, { passive: true });
    addEventListener('resize', onScroll);
    measure();
    return () => { removeEventListener('scroll', onScroll); removeEventListener('resize', onScroll); cancelAnimationFrame(frame); };
  }, [ready]);

  // Keep the address on the section in view (without a history entry). Profile and tool routes are left alone, and so is
  // an address that changed since we last looked: that is a navigation whose hashchange has not been handled yet.
  useEffect(() => {
    const { keyOf, hashOf } = fns.current, current = keyOf(location.hash);
    if (!ready || current === null || current === active || current !== addressKey.current || held.current) return;
    history.replaceState(history.state, '', hashOf(active));
    addressKey.current = active;
  }, [active, ready]);

  // Deep link on load, then pills / rail / links: scroll to the section the address names.
  useLayoutEffect(() => {
    if (!ready) return;
    addressKey.current = fns.current.keyOf(location.hash);
    const first = baseOf(location.hash);
    if (first && first !== fns.current.keys[0]) scrollToSection(first, 'auto');
    const onHash = () => {
      const key = addressKey.current = fns.current.keyOf(location.hash);
      if (key && key !== activeRef.current) scrollToSection(key, motion());
    };
    // A pill for the section already in view still returns to the section's start (the address follows as usual).
    const onClick = (e) => {
      const a = e.target instanceof Element && e.target.closest('a.tabs__btn[href^="#"]');
      if (!a || e.defaultPrevented || e.metaKey || e.ctrlKey || e.shiftKey) return;
      const href = a.getAttribute('href'), key = fns.current.keyOf(href);
      if (!key || key !== activeRef.current || fns.current.keyOf(location.hash) === null) return;
      if (location.hash === href) e.preventDefault();
      scrollToSection(key, motion());
    };
    addEventListener('hashchange', onHash);
    document.addEventListener('click', onClick, true);
    return () => { removeEventListener('hashchange', onHash); document.removeEventListener('click', onClick, true); };
  }, [ready]);

  // Focusing a pill (Tab, the shell's keys) must not move the page. Chrome scrolls a focused element in the stuck bar
  // toward the bar's unstuck place, before focusin; the page's scroll event comes after, so the last one seen is where we were.
  useEffect(() => {
    if (!ready) return;
    let stableY = scrollY;
    const onScroll = () => { stableY = scrollY; };
    const onFocus = (e) => {
      if (e.target instanceof Element && e.target.closest(':is(.appbar, .portfolio-appbar)') && scrollY !== stableY) scrollTo({ top: stableY, behavior: 'instant' });
    };
    addEventListener('scroll', onScroll, { passive: true });
    document.addEventListener('focusin', onFocus, true);
    return () => { removeEventListener('scroll', onScroll); document.removeEventListener('focusin', onFocus, true); };
  }, [ready]);

  // Sections rise into place the first time they come into view.
  useEffect(() => {
    if (!ready) return;
    const root = document.documentElement;
    root.classList.add('sections-ready');
    const seen = new IntersectionObserver((entries) => {
      for (const en of entries) if (en.isIntersecting) { en.target.classList.add('is-shown'); seen.unobserve(en.target); }
    }, { rootMargin: '0px 0px -6% 0px', threshold: 0 });
    document.querySelectorAll('[data-section]').forEach((el) => seen.observe(el));
    return () => seen.disconnect();
  }, [ready]);

  // The pill bar's thumb glides to the active pill; the bar scrolls (never the page) to keep it in view.
  useLayoutEffect(() => {
    const place = () => {
      const pill = document.querySelector('.tabs .tabs__btn[aria-current="page"]'), bar = pill?.closest('.tabs'), thumb = bar?.querySelector('.tabs__thumb');
      if (!(thumb instanceof HTMLElement) || !(pill instanceof HTMLElement)) { if (thumb instanceof HTMLElement) thumb.style.opacity = '0'; return; }
      thumb.style.setProperty('--x', `${pill.offsetLeft}px`);
      thumb.style.setProperty('--w', `${pill.offsetWidth}px`);
      thumb.style.opacity = '1';
      requestAnimationFrame(() => thumb.classList.add('is-placed'));
      if (bar.scrollWidth > bar.clientWidth) bar.scrollTo({ left: pill.offsetLeft - (bar.clientWidth - pill.offsetWidth) / 2, behavior: motion() });
    };
    place();
    // Re-measure whenever the bar or the pill changes size (viewport, fonts, the bar's rows rearranging on phones).
    const pill = document.querySelector('.tabs .tabs__btn[aria-current="page"]'), resized = new ResizeObserver(() => place());
    if (pill) { resized.observe(pill); resized.observe(pill.closest('.tabs')); }
    return () => resized.disconnect();
  }, [active, ready]);

  // The bar sticks with its pill row at the top. Where the bar wraps (phones), its tools sit on the row above the pills
  // (sections.css) and scroll away, so a long page keeps its section pills without a tall sticky header. Desktop: top is 0.
  useLayoutEffect(() => {
    if (!ready) return;
    const tabs = document.querySelector(':is(.appbar, .portfolio-appbar) .tabs'), bar = tabs?.closest(':is(.appbar, .portfolio-appbar)');
    if (!(tabs instanceof HTMLElement) || !(bar instanceof HTMLElement)) return;
    const pin = () => {
      const pad = parseFloat(getComputedStyle(tabs.parentElement).paddingTop) || 0;
      bar.style.top = `${Math.min(0, pad - (tabs.getBoundingClientRect().top - bar.getBoundingClientRect().top))}px`;
    };
    pin();
    // The bar's rows change with the viewport and with its tools (a currency switch appears once data is in).
    const resized = new ResizeObserver(pin);
    resized.observe(bar);
    return () => resized.disconnect();
  }, [ready]);

  return { active };
}
