export const BOARD_LEVEL_TAGS = [
  'Board level',
  'Damaging admission',
  'Deposition exhibit candidate',
  'Financial anomaly',
  'Hot document',
  'Key custodian mention',
  'Privilege candidate',
  'Regulatory reference',
];

export const CODING_FORMS = ['Responsive', 'Not responsive', 'Privileged', 'Confidential', 'Redact'];

export const QUEUES = [
  ['unassigned', 'Unassigned'],
  ['assigned', 'Assigned'],
  ['in_progress', 'In progress'],
  ['completed', 'Completed'],
];

const QUEUE_TONE = {
  unassigned: 'var(--svc-4)',
  assigned: 'var(--svc-1)',
  in_progress: 'var(--svc-5)',
  completed: 'var(--svc-0)',
};
export const queueTone = (queue) => QUEUE_TONE[queue] || 'var(--ink-2)';

export function roundHalfUp(num, decimals = 1) {
  if (Number.isNaN(num) || !Number.isFinite(num)) return 0;
  const sign = num >= 0 ? 1 : -1;
  const factor = 10 ** decimals;
  return (sign * Math.floor(Math.abs(num) * factor + 0.5 + Number.EPSILON)) / factor;
}

export function getBand(score) {
  if (score == null) return null;
  if (score >= 7) return 'very good';
  if (score >= 6) return 'good';
  return 'below';
}

export function bandLabel(band) {
  if (band === 'very good') return 'Very good';
  if (band === 'good') return 'Good';
  if (band === 'below') return 'Below';
  return '';
}

export function getBoardLevelTags(doc) {
  const result = [];
  const numId = parseInt(String(doc.id).replace(/\D/g, ''), 10) || 0;
  if (doc.tags?.includes('Hot')) result.push('Hot document');
  if (doc.tags?.includes('Privileged')) result.push('Privilege candidate');
  if (doc.assignment === 'Executive Communications' || numId % 7 === 0) result.push('Board level');
  if (doc.assignment === 'Engineering and Battery Safety' || numId % 5 === 0) result.push('Damaging admission');
  if (doc.assignment === 'Carrier correspondence' || numId % 6 === 0) result.push('Deposition exhibit candidate');
  if (doc.assignment === 'Financial Reconciliations' || doc.assignment === 'Demurrage invoices' || numId % 4 === 0) result.push('Financial anomaly');
  if (doc.title?.includes('Memo') || doc.title?.includes('Email') || numId % 8 === 0) result.push('Key custodian mention');
  if (doc.securityGroup === 'Privilege review' || numId % 9 === 0) {
    if (!result.includes('Privilege candidate')) result.push('Privilege candidate');
  }
  if (doc.projectId === 'A30048' || numId % 11 === 0) result.push('Regulatory reference');
  if (!result.length) result.push(BOARD_LEVEL_TAGS[numId % BOARD_LEVEL_TAGS.length]);
  return [...new Set(result)];
}

export function getCodingForms(doc) {
  if (doc.queue === 'unassigned' || !doc.tags) return [];
  return doc.tags.filter((tag) => CODING_FORMS.includes(tag));
}

function meanScore(parts) {
  const present = parts.filter((value) => value != null);
  if (!present.length) return null;
  return roundHalfUp(present.reduce((sum, value) => sum + value, 0) / present.length, 1);
}

export function computeMetricsFromDocs(docs) {
  let unassigned = 0, assigned = 0, inProgress = 0, completed = 0, released = 0;
  let checked = 0, misses = 0, defects = 0, estMin = 0, actMin = 0, timedCount = 0, plannedMin = 0;
  const byReviewer = new Map();
  for (const doc of docs) {
    plannedMin += doc.estimatedMinutes || 0;
    if (doc.queue === 'unassigned') unassigned += 1;
    else if (doc.queue === 'assigned') assigned += 1;
    else if (doc.queue === 'in_progress') inProgress += 1;
    else if (doc.queue === 'completed') {
      completed += 1;
      if (doc.released) released += 1;
      if (doc.checked) { checked += 1; if (doc.miss) misses += 1; }
      if (doc.defect) defects += 1;
      if (doc.reviewer) {
        if (!byReviewer.has(doc.reviewer)) byReviewer.set(doc.reviewer, []);
        byReviewer.get(doc.reviewer).push(doc);
      }
    }
    if (doc.timed) {
      timedCount += 1;
      estMin += doc.estimatedMinutes || 0;
      actMin += doc.actualMinutes || 0;
    }
  }
  const accuracy = checked > 0 ? roundHalfUp(10 * (1 - misses / checked), 1) : null;
  const defectScore = completed > 0 ? roundHalfUp(10 * (1 - defects / completed), 1) : null;
  let timeScore = null;
  if (timedCount > 0 && actMin > 0) timeScore = actMin <= estMin ? 10 : roundHalfUp((10 * estMin) / actMin, 1);
  const score = meanScore([accuracy, defectScore, timeScore]);
  const reviewersUnder7List = [];
  for (const [name, rows] of byReviewer) {
    const personScore = meanScore(pace(rows));
    if (personScore != null && personScore < 7) reviewersUnder7List.push({ name, score: personScore });
  }
  reviewersUnder7List.sort((a, b) => b.score - a.score);
  return {
    unassigned, assigned, inProgress, completed, released, checked, misses, defects, accuracy, defectScore,
    plannedMinutes: plannedMin, estimatedMinutes: estMin, actualMinutes: actMin, timedCount,
    avgMinutes: timedCount > 0 ? roundHalfUp(actMin / timedCount, 1) : null,
    timeScore, score,
    band: getBand(score),
    clientPaysUsd: completed * 10, reviewerPaidUsd: completed * 5, revenueUsd: completed * 5,
    relativityCostUsd: completed * 8, savingVersusRelativityUsd: completed * 3,
    reviewersBelowLine: reviewersUnder7List.length, reviewersUnder7List,
  };
}

function pace(docs) {
  let checked = 0, misses = 0, defects = 0, completed = 0, est = 0, act = 0, timed = 0;
  for (const doc of docs) {
    if (doc.queue === 'completed') {
      completed += 1;
      if (doc.defect) defects += 1;
    }
    if (doc.checked) { checked += 1; if (doc.miss) misses += 1; }
    if (doc.timed) { timed += 1; est += doc.estimatedMinutes || 0; act += doc.actualMinutes || 0; }
  }
  const accuracy = checked > 0 ? roundHalfUp(10 * (1 - misses / checked), 1) : null;
  const defectScore = completed > 0 ? roundHalfUp(10 * (1 - defects / completed), 1) : null;
  const timeScore = timed > 0 && act > 0 ? (act <= est ? 10 : roundHalfUp((10 * est) / act, 1)) : null;
  return [accuracy, defectScore, timeScore];
}

export function computeDirection(curr, prev, type) {
  if (curr == null || prev == null) {
    if (type === 'checked') return { direction: 'no checked documents', changePercent: 0 };
    if (type === 'timed') return { direction: 'no timed documents', changePercent: 0 };
    return { direction: 'unchanged', changePercent: 0 };
  }
  if (prev === 0) return curr === 0 ? { direction: 'unchanged', changePercent: 0 } : { direction: 'increased', changePercent: 100 };
  const diff = curr - prev;
  if (Math.abs(diff) < 0.001) return { direction: 'unchanged', changePercent: 0 };
  const pct = roundHalfUp((diff / prev) * 100, 1);
  if (pct > 0) return { direction: 'increased', changePercent: Math.abs(pct) };
  if (pct < 0) return { direction: 'decreased', changePercent: Math.abs(pct) };
  return { direction: 'unchanged', changePercent: 0 };
}

export function computeDirections(curr, prev) {
  return {
    accuracy: computeDirection(curr.accuracy, prev.accuracy, 'checked'),
    defects: computeDirection(curr.defects, prev.defects),
    completed: computeDirection(curr.completed, prev.completed),
    timeScore: computeDirection(curr.timeScore, prev.timeScore, 'timed'),
    avgMinutes: computeDirection(curr.avgMinutes, prev.avgMinutes, 'timed'),
    revenueUsd: computeDirection(curr.revenueUsd, prev.revenueUsd),
    unassigned: computeDirection(curr.unassigned, prev.unassigned),
    assigned: computeDirection(curr.assigned, prev.assigned),
    inProgress: computeDirection(curr.inProgress, prev.inProgress),
    released: computeDirection(curr.released, prev.released),
    score: computeDirection(curr.score, prev.score),
  };
}

export function computeReviewerRows(docs, names) {
  const groups = new Map(names.map((name) => [name, []]));
  for (const doc of docs) {
    if (!doc.reviewer) continue;
    if (!groups.has(doc.reviewer)) groups.set(doc.reviewer, []);
    groups.get(doc.reviewer).push(doc);
  }
  const rows = [];
  for (const [reviewer, group] of groups) {
    if (!group.length) continue;
    let assigned = 0, inProgress = 0, completed = 0, released = 0, checked = 0, misses = 0, defects = 0;
    for (const doc of group) {
      if (doc.queue === 'assigned') assigned += 1;
      else if (doc.queue === 'in_progress') inProgress += 1;
      else if (doc.queue === 'completed') {
        completed += 1;
        if (doc.released) released += 1;
        if (doc.checked) { checked += 1; if (doc.miss) misses += 1; }
        if (doc.defect) defects += 1;
      }
    }
    const [accuracy, defectScore, timeScore] = pace(group);
    const score = meanScore([accuracy, defectScore, timeScore]);
    rows.push({ reviewer, assigned, inProgress, completed, released, checked, misses, defects, accuracy, timeScore, score, band: getBand(score) });
  }
  return rows.sort((a, b) => b.completed - a.completed || a.reviewer.localeCompare(b.reviewer));
}

function blankHeat(tags) {
  return Object.fromEntries(tags.map((tag) => [tag, { unassigned: 0, assigned: 0, in_progress: 0, completed: 0, documents: 0 }]));
}

export function computeTagHeatmap(docs) {
  const heat = blankHeat(BOARD_LEVEL_TAGS);
  for (const doc of docs) {
    for (const tag of getBoardLevelTags(doc)) {
      heat[tag][doc.queue] += 1;
      heat[tag].documents += 1;
    }
  }
  return heat;
}

export function computeCodingHeatmap(docs) {
  const heat = blankHeat(CODING_FORMS);
  for (const doc of docs) {
    for (const form of getCodingForms(doc)) {
      if (doc.queue in heat[form]) heat[form][doc.queue] += 1;
      heat[form].documents += 1;
    }
  }
  return heat;
}

export function computePersonToQueue(docs) {
  const map = new Map();
  for (const doc of docs) {
    if (!doc.reviewer) continue;
    if (!map.has(doc.reviewer)) map.set(doc.reviewer, { reviewer: doc.reviewer, assigned: 0, inProgress: 0, completed: 0, released: 0 });
    const row = map.get(doc.reviewer);
    if (doc.queue === 'assigned') row.assigned += 1;
    else if (doc.queue === 'in_progress') row.inProgress += 1;
    else if (doc.queue === 'completed') {
      row.completed += 1;
      if (doc.released) row.released += 1;
    }
  }
  return [...map.values()].sort((a, b) => b.completed - a.completed || a.reviewer.localeCompare(b.reviewer));
}

export function getPreviousWindow(fromStr, toStr) {
  const fromDate = new Date(fromStr);
  const toDate = new Date(toStr);
  const diffDays = Math.ceil(Math.abs(toDate.getTime() - fromDate.getTime()) / 86400000) + 1;
  const prevTo = new Date(fromDate);
  prevTo.setDate(prevTo.getDate() - 1);
  const prevFrom = new Date(prevTo);
  prevFrom.setDate(prevFrom.getDate() - diffDays + 1);
  const format = (date) => date.toISOString().split('T')[0];
  return { previousFrom: format(prevFrom), previousTo: format(prevTo) };
}

export function attachVariance(rows) {
  const mean = (list) => (list.length ? list.reduce((total, value) => total + value, 0) / list.length : null);
  const avgScore = mean(rows.map((row) => row.score).filter((value) => value != null));
  const avgAccuracy = mean(rows.map((row) => row.accuracy).filter((value) => value != null));
  const avgDone = mean(rows.map((row) => row.completed));
  const doneBase = avgDone == null ? null : roundHalfUp(avgDone, 0);
  return rows.map((row) => ({
    ...row,
    scoreGap: row.score == null || avgScore == null ? null : roundHalfUp(row.score - avgScore, 1),
    accuracyGap: row.accuracy == null || avgAccuracy == null ? null : roundHalfUp(row.accuracy - avgAccuracy, 1),
    volumeGap: doneBase == null ? null : row.completed - doneBase,
  }));
}

export function completionSeries(docs) {
  const weeks = new Map();
  const months = new Map();
  for (const doc of docs) {
    if (doc.queue !== 'completed') continue;
    const month = doc.date.slice(0, 7);
    months.set(month, (months.get(month) || 0) + 1);
    const date = new Date(`${doc.date}T00:00:00Z`);
    const weekday = date.getUTCDay() || 7;
    const monday = new Date(date);
    monday.setUTCDate(date.getUTCDate() - weekday + 1);
    const key = monday.toISOString().slice(0, 10);
    weeks.set(key, (weeks.get(key) || 0) + 1);
  }
  const toItems = (map) => [...map.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([key, value]) => ({ key, label: key.slice(5), short: key.slice(5), value }));
  return { weeks: toItems(weeks), months: toItems(months) };
}

export function rollup(docs, keyFn) {
  const groups = new Map();
  for (const doc of docs) {
    const key = keyFn(doc) || 'Unknown';
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(doc);
  }
  return [...groups.entries()].map(([label, group]) => {
    const metrics = computeMetricsFromDocs(group);
    const first = group[0] || {};
    const parent = first.projectName === label ? first.domain : first.domain === label ? first.client : '';
    return {
      key: label,
      label,
      parent,
      value: metrics.completed,
      completed: metrics.completed,
      note: metrics.score == null ? '' : `score ${metrics.score.toFixed(1)}`,
      score: metrics.score,
      accuracy: metrics.accuracy,
      defectScore: metrics.defectScore,
      misses: metrics.misses,
      checked: metrics.checked,
      defects: metrics.defects,
      released: metrics.released,
      avgMinutes: metrics.avgMinutes,
      revenue: metrics.revenueUsd,
      relativity: metrics.relativityCostUsd,
      reviewerPaid: metrics.reviewerPaidUsd,
      saving: metrics.savingVersusRelativityUsd,
    };
  }).sort((a, b) => b.value - a.value);
}

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const dayLabel = (date) => `${MONTHS[Number(date.slice(5, 7)) - 1]} ${Number(date.slice(8, 10))}`;
const mondayOf = (date) => {
  const day = new Date(`${date}T00:00:00Z`);
  day.setUTCDate(day.getUTCDate() - (day.getUTCDay() || 7) + 1);
  return day.toISOString().slice(0, 10);
};

// Groups finished reviews by the finest useful unit, so a short period still has a trend.
export function trendBy(docs, keyFn) {
  const done = docs.filter((doc) => doc.queue === 'completed');
  const monthCount = new Set(done.map((doc) => doc.date.slice(0, 7))).size;
  const dayCount = new Set(done.map((doc) => doc.date)).size;
  const unit = monthCount >= 2 ? 'month' : dayCount <= 10 ? 'day' : 'week';
  const bucket = { month: (doc) => doc.date.slice(0, 7), week: (doc) => mondayOf(doc.date), day: (doc) => doc.date }[unit];
  const groups = new Map();
  for (const doc of done) {
    const key = keyFn(doc) || 'Unknown';
    if (!groups.has(key)) groups.set(key, new Map());
    const counts = groups.get(key);
    counts.set(bucket(doc), (counts.get(bucket(doc)) || 0) + 1);
  }
  const buckets = [...new Set(done.map(bucket))].sort();
  return {
    unit,
    periods: buckets.map((item) => (unit === 'month' ? MONTHS[Number(item.slice(5)) - 1] : dayLabel(item))),
    series: [...groups.entries()].map(([label, counts], index) => ({
      key: label, label, color: `var(--svc-${index % 5})`, values: buckets.map((item) => counts.get(item) || 0),
    })),
  };
}

// Finished reviews per week, month, quarter or year. `selected` marks the buckets inside the chosen period.
export function completionBy(docs, unit, from, to) {
  const keyOf = {
    week: (date) => mondayOf(date),
    month: (date) => date.slice(0, 7),
    quarter: (date) => `${date.slice(0, 4)}-Q${Math.ceil(Number(date.slice(5, 7)) / 3)}`,
    year: (date) => date.slice(0, 4),
  }[unit];
  const labelOf = {
    week: (key) => `${dayLabel(key)}, ${key.slice(0, 4)}`,
    month: (key) => `${MONTHS[Number(key.slice(5)) - 1]} ${key.slice(0, 4)}`,
    quarter: (key) => `${key.slice(5)} ${key.slice(0, 4)}`,
    year: (key) => key,
  }[unit];
  const buckets = new Map();
  for (const doc of docs) {
    if (doc.queue !== 'completed') continue;
    const key = keyOf(doc.date);
    const item = buckets.get(key) || { key, label: labelOf(key), value: 0, selected: false };
    item.value += 1;
    if (doc.date >= from && doc.date <= to) item.selected = true;
    buckets.set(key, item);
  }
  let total = 0;
  return [...buckets.values()].sort((a, b) => a.key.localeCompare(b.key)).map((item) => { total += item.value; return { ...item, total }; });
}

// Estimated time covers every document. Actual time exists only once a document has been reviewed.
export function timeTotals(docs) {
  const totals = { documents: docs.length, reviewed: 0, planned: 0, estimated: 0, actual: 0 };
  for (const doc of docs) {
    totals.planned += doc.estimatedMinutes || 0;
    if (doc.queue !== 'completed') continue;
    totals.reviewed += 1;
    totals.estimated += doc.estimatedMinutes || 0;
    totals.actual += doc.actualMinutes || 0;
  }
  return totals;
}

export function heatRows(tags, heat, { coding = false, totals } = {}) {
  const counts = tags.flatMap((tag) => QUEUES.map(([queue]) => heat[tag]?.[queue] || 0));
  const max = Math.max(1, ...counts);
  return tags.map((tag) => ({
    key: tag,
    label: tag,
    cells: QUEUES.map(([queue, label]) => {
      const count = heat[tag]?.[queue] || 0;
      const empty = coding && queue === 'unassigned';
      const base = totals?.[queue] || 0;
      const share = !empty && base ? (count / base) * 100 : null;
      const aria = empty ? 'not applicable' : share == null ? `${count} documents` : `${count} documents, ${share.toFixed(1)} percent of ${label}`;
      return { v: empty ? 0 : count / max, label: count, share, empty, aria };
    }),
  }));
}
