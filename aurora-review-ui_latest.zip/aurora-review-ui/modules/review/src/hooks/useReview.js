import { useQuery } from '@tanstack/react-query';
import { reviewService } from '@siloverse/services';

export const useReview = () => useQuery({
  queryKey: ['review', 'landing'],
  queryFn: () => reviewService.getLanding(),
});
