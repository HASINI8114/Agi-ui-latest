import { useLayoutEffect } from 'react';

// Review's take on @siloverse/ui/editorial-motion: same observer, same 60ms sibling stagger.
// Review renders through shared components that cannot carry data-reveal, so targets are tagged here.
// `data-in` is used instead of the `is-in` class because React rewrites className when a row's state changes.
const TARGETS = [
  ['.doc-head, .vhead', 'head'],
  ['.score-block, .statline > div, .heads > li, .panel', ''],
  ['.rank li, .cmp-table tbody tr, .heat__row > *', 'row'],
];

export function useScrollMotion(ref) {
  useLayoutEffect(() => {
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) return undefined;
    const root = ref.current;
    const order = new Map();
    const observer = new IntersectionObserver((entries) => {
      for (const entry of entries) {
        if (!entry.isIntersecting) continue;
        entry.target.setAttribute('data-in', '');
        observer.unobserve(entry.target);
      }
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.04 });
    const bound = new WeakSet();
    const bind = () => {
      for (const [selector, kind] of TARGETS) {
        for (const element of root.querySelectorAll(selector)) {
          if (bound.has(element)) continue;
          bound.add(element);
          element.setAttribute('data-reveal', kind);
          const index = order.get(element.parentElement) ?? 0;
          order.set(element.parentElement, index + 1);
          element.style.setProperty('--d', `${Math.min(index, 8) * 60}ms`);
          observer.observe(element);
        }
      }
    };
    bind();
    const changes = new MutationObserver(bind);
    changes.observe(root, { childList: true, subtree: true });
    document.documentElement.classList.add('is-enhanced');
    return () => {
      changes.disconnect();
      observer.disconnect();
      document.documentElement.classList.remove('is-enhanced');
    };
  }, [ref]);
}
