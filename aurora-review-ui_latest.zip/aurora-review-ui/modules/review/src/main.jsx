import React from 'react';
import { createRoot } from 'react-dom/client';
import { QueryProvider } from '@siloverse/ui/query';
import { renderWhenSignedIn } from '@siloverse/ui/session';
import { ModuleApp } from './App.jsx';

renderWhenSignedIn(() => createRoot(document.getElementById('root')).render(<QueryProvider><ModuleApp /></QueryProvider>));
