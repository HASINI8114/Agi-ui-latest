import React, { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import '@fontsource-variable/inter';
import './styles/review.css';
import '@siloverse/ui/accents.css';
import '@siloverse/ui/sections.css';
import { Heatmap, Ring } from '@siloverse/ui/charts';
import { useSectionScroll } from '@siloverse/ui/sections';
import { Bars, Empty, Icon, Panel, Seg, Select, initials } from '@siloverse/ui/primitives';
import {
  BOARD_LEVEL_TAGS, CODING_FORMS, QUEUES, attachVariance, bandLabel, completionBy, computeCodingHeatmap,
  computeDirection, computeDirections, computeMetricsFromDocs, computePersonToQueue, computeReviewerRows,
  computeTagHeatmap, getBand, getBoardLevelTags, getCodingForms, getPreviousWindow, heatRows, queueTone, rollup, timeTotals, trendBy,
} from './analytics.js';
import { useReview } from './hooks/useReview.js';
import { useScrollMotion } from './hooks/useScrollMotion.js';

const SECTIONS = [
  ['intelligence', 'Intelligence', 'spark'],
  ['analytics', 'Analytics', 'grid'],
  ['queues', 'Queues', 'flow'],
  ['workload', 'Workload', 'clock'],
  ['reviewers', 'Reviewers', 'star'],
  ['tags', 'Tags', 'filter'],
  ['documents', 'Documents', 'list'],
];
const FIGURES = [['count', 'Numbers'], ['percent', 'Percent'], ['both', 'Both']];
const PERIODS = [
  ['daily', 'Daily'], ['weekly', 'Weekly'], ['monthly', 'Monthly'], ['quarterly', 'Quarterly'],
  ['halfYearly', 'Half yearly'], ['yearly', 'Yearly'], ['custom', 'Custom'],
];
const VIEWS = [['clients', 'Clients'], ['domains', 'Domains'], ['projects', 'Projects']];
const PAGE = 8;
const TABLE_ROWS = 8;
const RANKED_ROWS = 8;
const UNITS = [['week', 'Week'], ['month', 'Month'], ['quarter', 'Quarter'], ['year', 'Year']];
const usd = (value) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(Math.round(value));
const one = (value) => (value == null ? 'N/A' : Number(value).toFixed(1));
const num = (value) => new Intl.NumberFormat('en-US').format(value || 0);
const time = (minutes) => (minutes == null ? 'N/A' : minutes < 60 ? `${Math.round(minutes)} min` : `${new Intl.NumberFormat('en-US', { maximumFractionDigits: minutes >= 6000 ? 0 : 1 }).format(minutes / 60)} h`);
const plural = (count, noun) => `${num(count)} ${noun}${count === 1 ? '' : 's'}`;
const longDate = (date) => new Intl.DateTimeFormat('en-GB', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' }).format(new Date(`${date}T00:00:00Z`));
const capital = (text) => `${text[0].toUpperCase()}${text.slice(1)}`;
const pct = (part, whole) => `${(whole ? (part / whole) * 100 : 0).toFixed(1)}%`;
const bandClass = (score) => (score == null ? 'none' : (getBand(score) || 'none').replace(' ', '-'));
const sectionKey = (hash) => {
  const key = (hash || '').replace(/^#\/?/, '').split('?')[0].split('/')[0];
  return SECTIONS.some(([id]) => id === key) ? key : null;
};
const queueName = (queue) => (queue === 'in_progress' ? 'In progress' : queue === 'unassigned' ? 'Unassigned' : queue === 'released' ? 'Released to production' : `${queue[0].toUpperCase()}${queue.slice(1)}`);
const docQueue = (doc) => (doc.released ? 'Released to production' : queueName(doc.queue));

function Move({ dir }) {
  if (!dir) return null;
  if (dir.direction === 'unchanged') return <span className="delta delta--flat">Unchanged</span>;
  if (dir.direction !== 'increased' && dir.direction !== 'decreased') return <span className="delta delta--flat">{dir.direction}</span>;
  const up = dir.direction === 'increased';
  return <span className={`delta delta--${up ? 'up' : 'down'}`}><Icon name={up ? 'up' : 'down'} size={12} />{dir.direction} {Math.abs(dir.changePercent).toFixed(1)}%</span>;
}

function Gap({ value, noun, near = 0.2 }) {
  if (value == null) return null;
  if (Math.abs(value) < near) return <span className="delta delta--flat" title={`In line with the average ${noun}`}>= {noun}</span>;
  const up = value > 0;
  const amount = Number.isInteger(value) ? String(Math.abs(value)) : Math.abs(value).toFixed(1);
  return <span className={`delta delta--${up ? 'up' : 'down'}`} title={`${amount} ${up ? 'above' : 'below'} the average ${noun}`}>{up ? '+' : '−'}{amount} {noun}</span>;
}

// Counts up the first time it scrolls into view, like Figure in @siloverse/ui/editorial, and always ends on the true value.
function Count({ value, format = (item) => num(Math.round(item)) }) {
  const ref = useRef(null);
  const text = format(value);
  useEffect(() => {
    const element = ref.current;
    element.textContent = text;
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) return undefined;
    let frame;
    const observer = new IntersectionObserver(([entry]) => {
      if (!entry.isIntersecting) return;
      observer.disconnect();
      const start = performance.now();
      const tick = (time) => {
        const progress = Math.min(1, (time - start) / 1200);
        element.textContent = progress < 1 ? format(value * (1 - 2 ** (-10 * progress))) : text;
        if (progress < 1) frame = requestAnimationFrame(tick);
      };
      frame = requestAnimationFrame(tick);
    });
    observer.observe(element);
    return () => { observer.disconnect(); cancelAnimationFrame(frame); element.textContent = text; };
  }, [value, text]);
  return <span className="count"><span className="sr-only">{text}</span><span ref={ref} aria-hidden="true">{text}</span></span>;
}

// Word-by-word heading rise, the sectionHead treatment from @siloverse/ui/editorial.
function Title({ text, className }) {
  return (
    <h1 className={className} aria-label={text}>
      {text.split(/\s+/).map((word, index) => <React.Fragment key={`${word}${index}`}>{index ? ' ' : ''}<span className="w" aria-hidden="true" style={{ '--wi': index }}><span>{word}</span></span></React.Fragment>)}
    </h1>
  );
}

export function ModuleApp() {
  const { data: landing, error, refetch } = useReview();
  const [theme, setTheme] = useState(document.documentElement.dataset.theme || 'dark');
  const [period, setPeriod] = useState('quarterly');
  const [from, setFrom] = useState('2026-07-01');
  const [to, setTo] = useState('2026-09-30');
  const [client, setClient] = useState('All');
  const [domain, setDomain] = useState('All');
  const [project, setProject] = useState('All');
  const [view, setView] = useState('clients');
  const [group, setGroup] = useState('All');
  const [assignment, setAssignment] = useState('All');
  const [person, setPerson] = useState('All');
  const [docQuery, setDocQuery] = useState('');
  const [docQueueFilter, setDocQueueFilter] = useState('All');
  const [docSize, setDocSize] = useState('All');
  const [page, setPage] = useState(1);
  const [detail, setDetail] = useState(null);
  const opener = useRef(null);
  const mainRef = useRef(null);
  useScrollMotion(mainRef);

  useEffect(() => {
    const mo = new MutationObserver(() => setTheme(document.documentElement.dataset.theme || 'dark'));
    mo.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
    return () => mo.disconnect();
  }, []);
  useEffect(() => { setPage(1); }, [period, from, to, client, domain, project, group, assignment, person, docQuery, docQueueFilter, docSize]);
  useEffect(() => {
    if (!detail) return undefined;
    document.getElementById('detail-close')?.focus();
    const onKey = (event) => { if (event.key === 'Escape') setDetail(null); };
    addEventListener('keydown', onKey);
    return () => {
      removeEventListener('keydown', onKey);
      opener.current?.focus();
    };
  }, [detail]);

  function show(id) {
    const next = `#/${id}`;
    if (location.hash === next) {
      document.querySelector(`[data-section="${CSS.escape(id)}"]`)?.scrollIntoView({
        behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth',
        block: 'start',
      });
      return;
    }
    location.hash = next;
  }
  function toggleTheme() {
    const next = theme === 'light' ? 'dark' : 'light';
    setTheme(next);
    document.documentElement.dataset.theme = next;
    try { localStorage.setItem('consilio-theme', next); } catch { /* private mode */ }
  }
  function openDetail(event, next) {
    opener.current = event?.currentTarget || document.activeElement;
    setDetail(next);
  }
  function reset() {
    setPeriod('quarterly'); setClient('All'); setDomain('All'); setProject('All'); setGroup('All'); setAssignment('All'); setPerson('All');
    setDocQuery(''); setDocQueueFilter('All'); setDocSize('All');
  }

  const model = useMemo(() => {
    if (!landing) return null;
    const range = period === 'custom'
      ? { ...getPreviousWindow(from, to), from, to, label: `${from} to ${to}` }
      : landing.windows[period];
    const matchBase = (doc) => (client === 'All' || doc.client === client)
      && (domain === 'All' || doc.domain === domain)
      && (project === 'All' || doc.projectId === project)
      && (group === 'All' || doc.securityGroup === group)
      && (assignment === 'All' || doc.assignment === assignment);
    const inWindow = (doc, start, end) => doc.date >= start && doc.date <= end && matchBase(doc);
    const baseDocs = landing.documents.filter((doc) => inWindow(doc, range.from, range.to));
    const previousBase = landing.documents.filter((doc) => inWindow(doc, range.previousFrom, range.previousTo));
    const currentDocs = person === 'All' ? baseDocs : baseDocs.filter((doc) => doc.reviewer === person);
    const previousDocs = person === 'All' ? previousBase : previousBase.filter((doc) => doc.reviewer === person);
    const names = landing.catalog.reviewers.map((row) => row.reviewer);
    const metrics = computeMetricsFromDocs(currentDocs);
    const previous = computeMetricsFromDocs(previousDocs);
    return {
      label: range.label,
      previousLabel: range.previousLabel || `${range.previousFrom} to ${range.previousTo}`,
      metrics,
      previous,
      directions: computeDirections(metrics, previous),
      baseDocs,
      currentDocs,
      names,
      reviewers: attachVariance(computeReviewerRows(baseDocs, names)),
      board: computeTagHeatmap(currentDocs),
      coding: computeCodingHeatmap(currentDocs),
      workload: computePersonToQueue(baseDocs),
      range,
      historyDocs: landing.documents.filter((doc) => matchBase(doc) && (person === 'All' || doc.reviewer === person)),
      clients: rollup(currentDocs, (doc) => doc.client),
      domains: rollup(currentDocs, (doc) => doc.domain),
      projects: rollup(currentDocs, (doc) => doc.projectName),
      clientTrend: trendBy(currentDocs, (doc) => doc.client),
      domainTrend: trendBy(currentDocs, (doc) => doc.domain),
      projectTrend: trendBy(currentDocs, (doc) => doc.projectName),
      showUnder: period === 'quarterly' && client === 'All' && domain === 'All' && project === 'All' && group === 'All' && assignment === 'All' && person === 'All',
    };
  }, [landing, period, from, to, client, domain, project, group, assignment, person]);

  const { active } = useSectionScroll({
    keys: SECTIONS.map(([id]) => id),
    keyOf: sectionKey,
    hashOf: (key) => `#/${key}`,
    ready: !!model,
  });

  useEffect(() => {
    const label = SECTIONS.find(([id]) => id === active)?.[1] || 'Review';
    document.title = `${label} · Aurora Gateway of Intelligence`;
  }, [active]);

  const documents = useMemo(() => {
    if (!model) return [];
    const query = docQuery.trim().toLowerCase();
    return model.currentDocs.filter((doc) => {
      if (query && !`${doc.title} ${doc.id}`.toLowerCase().includes(query)) return false;
      if (docSize !== 'All' && doc.size !== docSize) return false;
      if (docQueueFilter === 'released') return doc.queue === 'completed' && doc.released;
      if (docQueueFilter !== 'All' && doc.queue !== docQueueFilter) return false;
      return true;
    });
  }, [model, docQuery, docQueueFilter, docSize]);

  const dirty = period !== 'quarterly' || client !== 'All' || domain !== 'All' || project !== 'All' || group !== 'All' || assignment !== 'All' || person !== 'All' || docQuery || docQueueFilter !== 'All' || docSize !== 'All';
  const domainChoices = [...new Set((landing?.catalog.projects || []).filter((item) => client === 'All' || item.client === client).map((item) => item.domain))];
  const projectChoices = (landing?.catalog.projects || []).filter((item) => (client === 'All' || item.client === client) && (domain === 'All' || item.domain === domain));
  const selectedProject = projectChoices.find((item) => item.projectId === project);
  const pages = Math.max(1, Math.ceil(documents.length / PAGE));
  const shown = documents.slice((page - 1) * PAGE, page * PAGE);

  return (
    <>
      <a className="skip-link" href="#main" onClick={(event) => { event.preventDefault(); document.getElementById('main')?.focus(); }}>Skip to content</a>
      <nav className="side-nav" aria-label="Review sections">
        {SECTIONS.map(([id, label, icon]) => (
          <a key={id} href={`#/${id}`} className={active === id ? 'is-on' : ''} aria-current={active === id ? 'page' : undefined} onClick={(event) => { event.currentTarget.blur(); if (location.hash === `#/${id}`) { event.preventDefault(); show(id); } }}>
            <Icon name={icon} size={18} />
            <span>{label}</span>
          </a>
        ))}
      </nav>
      <header className="site-header">
        <div className="wrap site-header__row">
          <a className="wordmark" href="#/intelligence" aria-label="Aurora Gateway of Intelligence, review home" onClick={(event) => { event.preventDefault(); show('intelligence'); }}>
            <svg viewBox="0 0 24 24" className="wordmark__mark" aria-hidden="true"><circle cx="12" cy="12" r="3.2" /><circle cx="12" cy="12" r="7" fill="none" /><circle cx="12" cy="12" r="10.5" fill="none" strokeDasharray="2 2.6" /></svg>
            Aurora Gateway of Intelligence <span className="wordmark__crumb">/ Review</span>
          </a>
          <button className="theme-toggle" type="button" onClick={toggleTheme} aria-label={`Switch to ${theme === 'light' ? 'dark' : 'light'} theme`}><Icon name={theme === 'light' ? 'moon' : 'sun'} /></button>
        </div>
      </header>
      <main id="main" ref={mainRef} tabIndex={-1} className="main">
        {error ? (
          <div className="wrap"><div className="empty empty--page"><h1 className="empty__title">Review performance didn’t load.</h1><p className="empty__text">Check your connection and try again.</p><button className="btn btn--primary" type="button" onClick={() => refetch()}>Try again</button></div></div>
        ) : !model ? (
          <div className="wrap loading" role="status" aria-busy="true"><span className="loading__bar" /><span className="sr-only">Loading review performance</span></div>
        ) : (
          <div className="wrap">
            <div className="filters">
              <Seg label="Period" size="sm" value={period} onChange={setPeriod} options={PERIODS} />
              {period === 'custom' && (
                <>
                  <label className="date-field">From<input type="date" value={from} onChange={(event) => setFrom(event.target.value)} /></label>
                  <label className="date-field">To<input type="date" value={to} onChange={(event) => setTo(event.target.value)} /></label>
                </>
              )}
              <Select label="Security group" value={group} onChange={setGroup} options={[['All', 'All security groups'], ...landing.catalog.securityGroups.map((item) => [item, item])]} />
              <Select label="Assignment" value={assignment} onChange={setAssignment} options={[['All', 'All assignments'], ...landing.catalog.assignments.map((item) => [item, item])]} />
              <Select label="Reviewer" value={person} onChange={setPerson} options={[['All', 'All reviewers'], ...model.names.map((name) => [name, name])]} />
              {person !== 'All' && <button className="btn btn--secondary" type="button" onClick={() => setPerson('All')}>All reviewers</button>}
              {dirty && <button className="btn btn--ghost" type="button" onClick={reset}>Reset</button>}
            </div>
            <p className="compare-note">Every increase or decrease compares {model.label} with {model.previousLabel}.</p>

            <Intelligence model={model} show={show} openDetail={openDetail} />
            <section id="analytics" data-section="analytics" aria-label="Analytics">
            <OrgPage
              key={view}
              kicker={`Analytics · ${model.label}`}
              viewSelect={<Select label="View" value={view} onChange={setView} options={VIEWS} />}
              scope={[
                view !== 'clients' && client !== 'All' && ['Client', client, () => { setClient('All'); setDomain('All'); setProject('All'); }],
                view !== 'domains' && domain !== 'All' && ['Domain', domain, () => { setDomain('All'); setProject('All'); }],
                view !== 'projects' && project !== 'All' && ['Project', landing.catalog.projects.find((item) => item.projectId === project)?.projectName, () => setProject('All')],
              ].filter(Boolean)}
              {...{
                clients: {
                  title: client === 'All' ? 'Clients' : client,
                  noun: client === 'All' ? 'client' : 'domain',
                  rows: client === 'All' ? model.clients : model.domains,
                  trend: client === 'All' ? model.clientTrend : model.domainTrend,
                  choice: <Select label="Client" value={client} onChange={(value) => { setClient(value); setDomain('All'); setProject('All'); }} options={[['All', 'All clients'], ...landing.catalog.clients.map((item) => [item, item])]} />,
                  onPick: (row) => { if (client === 'All') { setClient(row.key); setDomain('All'); setProject('All'); } else { setDomain(row.key); setProject('All'); setView('domains'); } show('analytics'); },
                },
                domains: {
                  title: domain === 'All' ? 'Domains' : domain,
                  noun: domain === 'All' ? 'domain' : 'project',
                  rows: domain === 'All' ? model.domains : model.projects,
                  trend: domain === 'All' ? model.domainTrend : model.projectTrend,
                  choice: <Select label="Domain" value={domain} onChange={(value) => { setDomain(value); setProject('All'); if (value !== 'All') { const owner = landing.catalog.projects.find((item) => item.domain === value); if (owner) setClient(owner.client); } }} options={[['All', 'All domains'], ...domainChoices.map((item) => [item, item])]} />,
                  onPick: (row) => { if (domain === 'All') { setClient(row.parent || 'All'); setDomain(row.key); setProject('All'); } else { const item = landing.catalog.projects.find((projectRow) => projectRow.projectName === row.key); if (item) setProject(item.projectId); setView('projects'); } show('analytics'); },
                },
                projects: {
                  title: 'Projects', noun: 'Project', rows: model.projects, trend: model.projectTrend,
                  choice: <Select label="Project" value={project} onChange={setProject} options={[['All', 'All projects'], ...projectChoices.map((item) => [item.projectId, item.projectName])]} />,
                  brief: selectedProject ? { name: selectedProject.projectName, parent: `${selectedProject.client} · ${selectedProject.domain}`, metrics: model.metrics, directions: model.directions } : null,
                  onPick: (row) => { const item = landing.catalog.projects.find((projectRow) => projectRow.projectName === row.key); if (item) { setClient(item.client); setDomain(item.domain); setProject(item.projectId); } show('analytics'); },
                },
              }[view]}
            />
            </section>
            <Queues model={model} openDetail={openDetail} />
            <Workload model={model} person={person} openDetail={openDetail} />
            <Reviewers model={model} person={person} setPerson={setPerson} openDetail={openDetail} />
            <Tags model={model} openDetail={openDetail} />
            <Documents
              landing={landing} model={model} documents={documents} shown={shown} page={page} pages={pages} setPage={setPage}
              docQuery={docQuery} setDocQuery={setDocQuery} docQueueFilter={docQueueFilter} setDocQueueFilter={setDocQueueFilter}
              docSize={docSize} setDocSize={setDocSize} openDetail={openDetail}
            />
          </div>
        )}
      </main>
      <footer className="site-footer"><div className="wrap site-footer__row"><span>Aurora Gateway of Intelligence</span>{model && <span>{model.label}</span>}</div></footer>
      {detail && <Detail detail={detail} onClose={() => setDetail((current) => current?.parent || null)} onDismiss={() => setDetail(null)} onOpen={(doc) => setDetail((current) => ({ title: doc.title, docs: [doc], single: true, parent: current }))} />}
      <div className="grain" aria-hidden="true" />
    </>
  );
}

function ShowToggle({ value, onChange }) {
  return <Seg label="Show" size="sm" value={value} onChange={onChange} options={FIGURES} />;
}

function useBox() {
  const ref = useRef(null);
  const [box, setBox] = useState({ width: 0, height: 0 });
  useLayoutEffect(() => {
    const observer = new ResizeObserver(([entry]) => {
      const { width, height } = entry.contentRect;
      setBox({ width: Math.round(width), height: Math.round(height) });
    });
    observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);
  return [ref, box];
}

function niceTicks(max, count = 4) {
  const raw = Math.max(1, max) / count;
  const magnitude = 10 ** Math.floor(Math.log10(raw));
  const step = [1, 2, 2.5, 5, 10].find((item) => item * magnitude >= raw) * magnitude;
  const steps = Math.ceil(Math.max(1, max) / step);
  return Array.from({ length: steps + 1 }, (_, index) => index * step);
}
const compact = (value) => (value >= 1000 ? `${Number((value / 1000).toFixed(1))}k` : String(value));

function ChartTip({ left, top, flip, children }) {
  return <div className={`chart-tip ${flip ? 'chart-tip--flip' : ''}`} style={{ left, top }}>{children}</div>;
}

function PeriodBars({ points, label }) {
  const [ref, { width, height }] = useBox();
  const [hover, setHover] = useState(null);
  const pad = { l: 46, r: 8, t: 22, b: 30 };
  const ticks = niceTicks(Math.max(1, ...points.map((point) => point.value)), 5);
  const top = ticks.at(-1);
  const innerW = Math.max(1, width - pad.l - pad.r);
  const innerH = Math.max(1, height - pad.t - pad.b);
  const band = innerW / Math.max(1, points.length);
  const barW = Math.max(2, Math.min(72, band * 0.72));
  const x = (index) => pad.l + band * index + (band - barW) / 2;
  const y = (value) => pad.t + innerH - (value / top) * innerH;
  const every = Math.max(1, Math.ceil(points.length / Math.max(2, Math.floor(innerW / 84))));
  const pick = (event) => {
    const box = event.currentTarget.getBoundingClientRect();
    setHover(Math.max(0, Math.min(points.length - 1, Math.floor((event.clientX - box.left - pad.l) / band))));
  };
  const point = hover == null ? null : points[hover];
  return (
    <div className="chart" ref={ref} onPointerMove={pick} onPointerLeave={() => setHover(null)}>
      {width > 0 && (
        <svg width={width} height={height} role="img" aria-label={label}>
          {ticks.map((value) => <g key={value}><line className="chart__grid" x1={pad.l} x2={width - pad.r} y1={y(value)} y2={y(value)} /><text className="chart__axis" x={pad.l - 10} y={y(value) + 4} textAnchor="end">{compact(value)}</text></g>)}
          {points.map((item, index) => (
            <g key={item.key} className={`pbar ${item.selected ? 'is-selected' : ''} ${hover === index ? 'is-hover' : ''}`} style={{ '--k': Math.min(index, 40) }}>
              <rect x={x(index)} y={y(item.value)} width={barW} height={Math.max(1, y(0) - y(item.value))} rx={Math.min(4, barW / 2)} />
              {points.length <= 12 && band > 48 && <text className="pbar__value" x={x(index) + barW / 2} y={y(item.value) - 7} textAnchor="middle">{compact(item.value)}</text>}
            </g>
          ))}
          {points.map((item, index) => ((points.length - 1 - index) % every === 0 ? <text key={item.key} className="chart__axis" x={index === points.length - 1 && points.length > 12 ? x(index) + barW : x(index) + barW / 2} y={height - 8} textAnchor={index === points.length - 1 && points.length > 12 ? 'end' : 'middle'}>{item.label}</text> : null))}
        </svg>
      )}
      {point && (
        <ChartTip left={x(hover) + barW / 2} top={Math.max(pad.t, y(point.value))} flip={hover >= points.length / 2}>
          <b>{point.label}</b>
          <span>{num(point.value)} finished</span>
          <span>{num(point.total)} running total</span>
        </ChartTip>
      )}
    </div>
  );
}

function MonthLines({ trend }) {
  const [ref, { width, height }] = useBox();
  const [hover, setHover] = useState(null);
  const pad = { l: 44, r: 18, t: 14, b: 30 };
  const { periods, series } = trend;
  const ticks = niceTicks(Math.max(1, ...series.flatMap((item) => item.values)));
  const top = ticks.at(-1);
  const innerW = Math.max(1, width - pad.l - pad.r);
  const innerH = Math.max(1, height - pad.t - pad.b);
  const x = (index) => pad.l + (periods.length <= 1 ? innerW / 2 : (index / (periods.length - 1)) * innerW);
  const y = (value) => pad.t + innerH - (value / top) * innerH;
  const pick = (event) => {
    const box = event.currentTarget.getBoundingClientRect();
    const index = Math.round(((event.clientX - box.left - pad.l) / innerW) * (periods.length - 1));
    setHover(Math.max(0, Math.min(periods.length - 1, index)));
  };
  const labelEvery = Math.max(1, Math.ceil(periods.length / Math.max(2, Math.floor(innerW / 64))));
  const ranked = hover == null ? [] : [...series].sort((a, b) => b.values[hover] - a.values[hover]);
  return (
    <div className="trend">
      <div className="chart" ref={ref} onPointerMove={pick} onPointerLeave={() => setHover(null)}>
        {width > 0 && (
          <svg width={width} height={height} role="img" aria-label="Documents completed each month">
            {ticks.map((value) => <g key={value}><line className="chart__grid" x1={pad.l} x2={width - pad.r} y1={y(value)} y2={y(value)} /><text className="chart__axis" x={pad.l - 10} y={y(value) + 4} textAnchor="end">{compact(value)}</text></g>)}
            {hover != null && <line className="chart__guide" x1={x(hover)} x2={x(hover)} y1={pad.t} y2={y(0)} />}
            {series.map((item, index) => (
              <g key={item.key} style={{ '--c': item.color, '--k': index }}>
                <path className="chart__line" pathLength="1" d={item.values.map((value, point) => `${point ? 'L' : 'M'}${x(point)},${y(value)}`).join(' ')} />
                {item.values.map((value, point) => <circle key={periods[point]} className="chart__dot" cx={x(point)} cy={y(value)} r={hover === point ? 5 : 3.5} />)}
              </g>
            ))}
            {periods.map((period, index) => ((periods.length - 1 - index) % labelEvery === 0 ? <text key={period} className="chart__axis" x={x(index)} y={height - 8} textAnchor={index === 0 ? 'start' : index === periods.length - 1 ? 'end' : 'middle'}>{period}</text> : null))}
          </svg>
        )}
        {hover != null && (
          <ChartTip left={x(hover)} top={pad.t} flip={hover >= periods.length / 2}>
            <b>{periods[hover]}</b>
            {ranked.map((item) => <span key={item.key} className="chart-tip__row"><i style={{ '--c': item.color }} />{item.label}<em>{num(item.values[hover])}</em></span>)}
          </ChartTip>
        )}
      </div>
      <ul className="trend__key">
        {series.map((item) => <li key={item.key}><i style={{ '--c': item.color }} /><span>{item.label}</span><b>{num(item.values.at(-1) || 0)}</b></li>)}
      </ul>
    </div>
  );
}

function QualityMap({ rows, noun, onPick }) {
  const [ref, { width, height }] = useBox();
  const [hover, setHover] = useState(null);
  const pad = { l: 44, r: 22, t: 16, b: 42 };
  const points = rows.filter((row) => row.accuracy != null);
  const floor = Math.max(0, Math.floor(Math.min(10, ...points.map((row) => row.accuracy)) - 1));
  const ticksX = niceTicks(Math.max(1, ...points.map((row) => row.completed)), 5);
  const maxX = ticksX.at(-1);
  const ticksY = Array.from({ length: 11 - floor }, (_, index) => floor + index).filter((value) => (10 - value) % (10 - floor > 5 ? 2 : 1) === 0);
  const innerW = Math.max(1, width - pad.l - pad.r);
  const innerH = Math.max(1, height - pad.t - pad.b);
  const x = (value) => pad.l + (value / maxX) * innerW;
  const y = (value) => pad.t + innerH - ((value - floor) / (10 - floor)) * innerH;
  const average = points.length ? points.reduce((sum, row) => sum + row.accuracy, 0) / points.length : 0;
  const lowest = new Set([...points].sort((a, b) => a.accuracy - b.accuracy).slice(0, 3).map((row) => row.key));
  const active = points.find((row) => row.key === hover);
  return (
    <div className="chart chart--map" ref={ref}>
      {width > 0 && (
        <svg width={width} height={height} role="group" aria-label={`Sample quality against reviews done, by ${noun}`}>
          {ticksY.map((value) => <g key={value}><line className="chart__grid" x1={pad.l} x2={width - pad.r} y1={y(value)} y2={y(value)} /><text className="chart__axis" x={pad.l - 10} y={y(value) + 4} textAnchor="end">{value}</text></g>)}
          {ticksX.map((value) => <text key={value} className="chart__axis" x={x(value)} y={height - 24} textAnchor={value === 0 ? 'start' : value === maxX ? 'end' : 'middle'}>{compact(value)}</text>)}
          <text className="chart__axis" x={pad.l + innerW / 2} y={height - 6} textAnchor="middle">Reviews done</text>
          <line className="chart__mean" x1={pad.l} x2={width - pad.r} y1={y(average)} y2={y(average)} />
          <text className="chart__axis" x={width - pad.r} y={y(average) - 6} textAnchor="end">Average {one(average)}</text>
          {points.map((row, index) => {
            const right = x(row.completed) < width * 0.72;
            return (
              <g key={row.key} className={`map-dot map-dot--${bandClass(row.accuracy)}`} style={{ '--k': index }}>
                <circle cx={x(row.completed)} cy={y(row.accuracy)} r={hover === row.key ? 9 : 7} tabIndex={0} role="button" aria-label={`Open ${row.label}: quality ${one(row.accuracy)}, ${num(row.completed)} reviews`}
                  onPointerEnter={() => setHover(row.key)} onPointerLeave={() => setHover(null)} onFocus={() => setHover(row.key)} onBlur={() => setHover(null)}
                  onClick={() => onPick(row)} onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); onPick(row); } }} />
                {lowest.has(row.key) && <text className="map-dot__name" x={x(row.completed) + (right ? 13 : -13)} y={y(row.accuracy) + 4} textAnchor={right ? 'start' : 'end'}>{row.label}</text>}
              </g>
            );
          })}
        </svg>
      )}
      {active && (
        <ChartTip left={x(active.completed)} top={y(active.accuracy)} flip={x(active.completed) > width / 2}>
          <b>{active.label}</b>
          <span>Quality {one(active.accuracy)} · {pct(active.misses, active.checked)} misses</span>
          <span>{num(active.completed)} reviews done</span>
        </ChartTip>
      )}
    </div>
  );
}

function Watchlist({ rows, onPick }) {
  const low = rows.filter((row) => row.accuracy != null).sort((a, b) => a.accuracy - b.accuracy).slice(0, 5);
  return (
    <ol className="watch">
      {low.map((row) => (
        <li key={row.key}>
          <button type="button" onClick={() => onPick(row)}>
            <span className="watch__name">{row.label}{row.parent ? <small>{row.parent}</small> : null}</span>
            <span className={`quality quality--${bandClass(row.accuracy)}`}>{one(row.accuracy)}</span>
            <span className="meter-line"><i style={{ '--v': row.accuracy / 10 }} /></span>
            <small className="watch__note">{pct(row.misses, row.checked)} misses · {num(row.misses)} of {num(row.checked)} checked</small>
          </button>
        </li>
      ))}
    </ol>
  );
}

const COLUMNS = [
  ['completed', 'Reviews done'], ['released', 'Released'], ['accuracy', 'Quality'], ['missRate', 'Misses'],
  ['defectRate', 'Defects'], ['avgMinutes', 'Minutes'], ['relativity', 'Relativity'], ['saving', 'AVR saving'],
];

function SliceTable({ rows, noun, onPick }) {
  const [sort, setSort] = useState({ key: 'completed', down: true });
  const [all, setAll] = useState(false);
  const top = Math.max(1, ...rows.map((row) => row.completed));
  const enriched = rows.map((row) => ({ ...row, missRate: row.checked ? row.misses / row.checked : null, defectRate: row.completed ? row.defects / row.completed : null }));
  const sorted = [...enriched].sort((a, b) => {
    const left = a[sort.key] ?? -1;
    const right = b[sort.key] ?? -1;
    return sort.down ? right - left : left - right;
  });
  const shown = all ? sorted : sorted.slice(0, TABLE_ROWS);
  return (
    <>
      <div className="cmp-wrap">
        <table className="cmp-table">
          <thead>
            <tr>
              <th scope="col">{noun}</th>
              {COLUMNS.map(([key, label]) => (
                <th key={key} scope="col" aria-sort={sort.key === key ? (sort.down ? 'descending' : 'ascending') : 'none'}>
                  <button type="button" className={sort.key === key ? 'is-on' : ''} onClick={() => setSort((current) => ({ key, down: current.key === key ? !current.down : true }))}>
                    {label}<Icon name={sort.key === key && !sort.down ? 'up' : 'down'} size={11} />
                  </button>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {shown.map((row) => (
              <tr key={row.key}>
                <td><button type="button" onClick={() => onPick(row)}>{row.label}{row.parent ? <small>{row.parent}</small> : null}</button></td>
                <td><span className="cmp-table__volume"><span className="meter-line"><i style={{ '--v': row.completed / top }} /></span>{num(row.completed)}</span></td>
                <td>{num(row.released)}</td>
                <td><span className={`quality quality--${bandClass(row.accuracy)}`}>{one(row.accuracy)}</span></td>
                <td>{row.checked ? pct(row.misses, row.checked) : 'N/A'}</td>
                <td>{num(row.defects)}<small>{pct(row.defects, row.completed)}</small></td>
                <td>{one(row.avgMinutes)}</td>
                <td>{usd(row.relativity)}</td>
                <td>{usd(row.saving)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {rows.length > TABLE_ROWS && (
        <div className="cmp-more">
          <span className="muted">Showing {num(shown.length)} of {num(rows.length)}</span>
          <button className="btn btn--secondary" type="button" onClick={() => setAll((value) => !value)}>{all ? 'Show fewer' : `Show all ${rows.length}`}</button>
        </div>
      )}
    </>
  );
}

function SliceBrief({ brief }) {
  const metrics = brief.metrics;
  return (
    <>
      <div className="statline">
        <div><span className="kicker">Reviews done</span><b><Count value={metrics.completed} /></b><small>{num(metrics.released)} released to production · {pct(metrics.released, metrics.completed)}</small>{brief.directions && <Move dir={brief.directions.completed} />}</div>
        <div><span className="kicker">Sample quality</span><b>{one(metrics.accuracy)}</b><small>{num(metrics.misses)} misses ÷ {num(metrics.checked)} checked</small></div>
        <div><span className="kicker">Reviews with defects</span><b>{num(metrics.defects)}</b><small>{pct(metrics.defects, metrics.completed)} of reviews done · score {one(metrics.defectScore)}</small></div>
        <div><span className="kicker">Average minutes</span><b>{one(metrics.avgMinutes)}</b><small>Pace {one(metrics.timeScore)} out of 10</small></div>
      </div>
      <div className="statline">
        <div><span className="kicker">Relativity would cost</span><b><Count value={metrics.relativityCostUsd} format={usd} /></b><small>$8 a completed document</small></div>
        <div><span className="kicker">AVR reviewer pay</span><b><Count value={metrics.reviewerPaidUsd} format={usd} /></b><small>$5 a completed document</small></div>
        <div><span className="kicker">AVR saving</span><b><Count value={metrics.savingVersusRelativityUsd} format={usd} /></b><small>{pct(metrics.savingVersusRelativityUsd, metrics.relativityCostUsd)} less than Relativity</small></div>
        <div><span className="kicker">Revenue</span><b><Count value={metrics.revenueUsd} format={usd} /></b><small>{pct(metrics.revenueUsd, metrics.clientPaysUsd)} of the $10 client fee</small></div>
      </div>
    </>
  );
}

function OrgPage({ kicker, title, noun, rows, trend, onPick, choice, viewSelect, scope, brief }) {
  const [figures, setFigures] = useState('both');
  const total = rows.reduce((sum, row) => sum + row.value, 0) || 1;
  const qualities = rows.map((row) => row.accuracy).filter((value) => value != null);
  const averageQuality = qualities.length ? qualities.reduce((sum, value) => sum + value, 0) / qualities.length : null;
  const saving = rows.reduce((sum, row) => sum + (row.saving || 0), 0);
  const relativity = rows.reduce((sum, row) => sum + (row.relativity || 0), 0);
  const Noun = `${noun[0].toUpperCase()}${noun.slice(1)}`;
  const lower = noun.toLowerCase();
  const chartSeries = [...trend.series].sort((a, b) => (b.values.at(-1) || 0) - (a.values.at(-1) || 0)).slice(0, 6).map((item, index) => ({ ...item, color: `var(--svc-${index})` }));
  const ranked = [...rows].sort((a, b) => b.value - a.value);
  const lede = brief
    ? `${brief.name}${brief.parent ? `, ${brief.parent}` : ''}. Reviewers finished ${num(brief.metrics.completed)} documents. Sample quality is ${one(brief.metrics.accuracy)}. Relativity would have cost ${usd(brief.metrics.relativityCostUsd)}. AVR saved ${usd(brief.metrics.savingVersusRelativityUsd)}, ${pct(brief.metrics.savingVersusRelativityUsd, brief.metrics.relativityCostUsd)} less.`
    : `${rows.length} ${lower}s. ${num(total)} reviews finished. AVR saved ${usd(saving)} against a Relativity cost of ${usd(relativity)}.`;
  return (
    <>
      <header className="doc-head">
        <div className="doc-head__top">
          <div>
            <p className="kicker">{kicker}</p>
            <Title text={brief ? brief.name : title} />
          </div>
          <div className="doc-head__tools">{viewSelect}{choice}</div>
        </div>
        <p className="doc-head__lede">{lede}</p>
        {scope.length > 0 && (
          <ul className="scope">
            {scope.map(([label, name, clear]) => <li key={label}><span>{label}</span>{name}<button type="button" aria-label={`Clear ${label.toLowerCase()} ${name}`} onClick={clear}><Icon name="close" size={12} /></button></li>)}
          </ul>
        )}
      </header>
      {brief ? <SliceBrief brief={brief} /> : (
        <div className="statline">
          <div><span className="kicker">{`${Noun}s`}</span><b><Count value={rows.length} /></b><small>In this period</small></div>
          <div><span className="kicker">Reviews done</span><b><Count value={total} /></b><small>Documents that finished review</small></div>
          <div><span className="kicker">Average quality</span><b>{averageQuality == null ? 'N/A' : <Count value={averageQuality} format={one} />}</b><small>Sample quality across these {lower}s</small></div>
          <div><span className="kicker">AVR saving</span><b><Count value={saving} format={usd} /></b><small>{pct(saving, relativity)} less than Relativity</small></div>
        </div>
      )}
      <div className="doc-bento">
        <Panel i={1} title={brief ? 'AVR against Relativity' : `Reviews done by ${lower}`} sub={brief ? 'Relativity is $8 a completed document. AVR pays the reviewer $5. The $3 difference is the saving.' : ranked.length > RANKED_ROWS ? `The ${RANKED_ROWS} largest of ${ranked.length}. Open a name to focus on it.` : 'Documents that finished review. Open a name to focus on it.'} action={brief ? null : <ShowToggle value={figures} onChange={setFigures} />}>
          {brief ? (
            <Bars items={[
              { key: 'rel', label: 'Relativity cost', value: brief.metrics.relativityCostUsd, note: '$8 a document' },
              { key: 'avr', label: 'AVR reviewer pay', value: brief.metrics.reviewerPaidUsd, note: '$5 a document' },
              { key: 'save', label: 'AVR saving', value: brief.metrics.savingVersusRelativityUsd, note: `${pct(brief.metrics.savingVersusRelativityUsd, brief.metrics.relativityCostUsd)} less than Relativity` },
            ]} format={(value) => usd(value)} />
          ) : (
            <Bars className={figures === 'both' ? 'bars--both' : ''} format={(value) => figureText(figures, value, total)} items={ranked.slice(0, RANKED_ROWS).map((row) => ({ key: row.key, label: row.label, value: row.value, note: `Quality ${one(row.accuracy)}`, onClick: () => onPick(row) }))} />
          )}
        </Panel>
        <Panel i={2} title={`Finished reviews by ${trend.unit}`} sub={trend.periods.length < 2 ? `Everything in this period finished on ${trend.periods[0] || 'no recorded day'}.` : chartSeries.length < trend.series.length ? `The six largest ${lower}s. Hover the chart for each ${trend.unit}.` : `Documents that finished review in each ${trend.unit}. Hover the chart for values.`}>
          {!chartSeries.length ? <Empty title="No finished reviews in this slice" text="Widen the period or clear a filter." />
            : trend.periods.length >= 2 ? <MonthLines trend={{ periods: trend.periods, series: chartSeries, unit: trend.unit }} />
              : <Bars items={chartSeries.map((item) => ({ key: item.key, label: item.label, value: item.values[0] }))} />}
        </Panel>
      </div>
      {!brief && rows.length > 0 && (
        <div className="doc-bento doc-bento--wide">
          <Panel i={3} title="Quality against volume" sub={`Each dot is a ${lower}. Further right is more reviews, lower down is weaker sample quality. The three lowest are named.`}>
            <QualityMap rows={rows} noun={lower} onPick={onPick} />
          </Panel>
          <Panel i={4} title="Lowest sample quality" sub="Where senior reviewers changed the most answers.">
            {qualities.length ? <Watchlist rows={rows} onPick={onPick} /> : <Empty title="No sampled documents" />}
          </Panel>
        </div>
      )}
      {!brief && (
        <Panel i={5} title="Compare" sub="Select a heading to sort, or a name to focus on it. Relativity costs $8 a document and AVR saves 37.5% of that.">
          {rows.length ? <SliceTable rows={rows} noun={Noun} onPick={onPick} /> : <Empty title={`No ${lower}s in this slice`} text="Widen the period or clear a filter." />}
        </Panel>
      )}
    </>
  );
}

function Intelligence({ model, show, openDetail }) {
  const metrics = model.metrics;
  const [unit, setUnit] = useState('month');
  const periods = useMemo(() => completionBy(model.historyDocs, unit, model.range.from, model.range.to), [model.historyDocs, model.range, unit]);
  return (
    <section id="intelligence" data-section="intelligence" aria-label="Intelligence">
      <header className="vhead">
        <div className="vhead__main"><Title className="vhead__title" text="Review performance" /><p className="vhead__tagline">The overall score, the fee, and where the work finished, for {model.label}.</p></div>
        <ul className="vhead__tags"><li>{num(model.currentDocs.length)} documents</li><li>{model.names.length} reviewers</li></ul>
      </header>
      <div className="score-block">
        <p className="kicker">Overall score · out of 10</p>
        <p className="hero-figure"><Count value={metrics.score ?? 0} format={one} /></p>
        <p className="note">{bandLabel(metrics.band) || 'No score'}{underTag(metrics, model) ? ` · ${underTag(metrics, model)}` : ''}. The score is the average of the three parts below.</p>
      </div>
      <div className="statline statline--3">
        <div>
          <span className="kicker">Sample quality</span>
          <b>{<Count value={metrics.accuracy ?? 0} format={one} />}</b>
          <small>{num(metrics.misses)} misses ÷ {num(metrics.checked)} checked. A miss is a senior reviewer changing responsive, privileged, or confidential on about 1 in 10.</small>
        </div>
        <div>
          <span className="kicker">Reviews with defects</span>
          <b><Count value={metrics.defectScore ?? 0} format={one} /></b>
          <small>10 × (1 − {num(metrics.defects)} defects ÷ {num(metrics.completed)} completed).</small>
        </div>
        <div>
          <span className="kicker">Pace</span>
          <b><Count value={metrics.timeScore ?? 0} format={one} /></b>
          <small>10 when actual minutes stay inside the estimate, otherwise 10 × estimated ÷ actual. Pages, language, density, and region set the estimate.</small>
        </div>
      </div>
      <ul className="heads">
        <Figure onClick={(event) => openDetail(event, { title: 'Reviews with defects', docs: model.currentDocs.filter((doc) => doc.defect) })} value={metrics.defects} label="Reviews with defects" dir={model.directions.defects} tags={[`${pct(metrics.defects, metrics.completed)} of documents completed`]} />
        <Figure onClick={(event) => openDetail(event, { title: 'Documents completed', docs: model.currentDocs.filter((doc) => doc.queue === 'completed') })} value={metrics.completed} label="Documents completed" dir={model.directions.completed} tags={[`${pct(metrics.released, metrics.completed)} released to production`]} />
        <Figure onClick={() => show('documents')} value={metrics.avgMinutes} format={one} label="Average minutes per document" dir={model.directions.avgMinutes} tags={[`${num(metrics.timedCount)} timed documents`, `${num(metrics.actualMinutes)} actual minutes`]} />
        <Figure onClick={() => document.getElementById('fee')?.scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'center' })} value={metrics.revenueUsd} format={usd} label="Revenue" dir={model.directions.revenueUsd} tags={[`${pct(metrics.revenueUsd, metrics.clientPaysUsd)} of the client fee`, `AVR saving ${usd(metrics.savingVersusRelativityUsd)}`]} />
      </ul>
      <div className="doc-bento">
        <Panel i={3} title="AVR against Relativity" sub="Relativity would cost $8 a completed document. AVR pays the reviewer $5. The $3 difference is the saving.">
          <Bars items={[
            { key: 'rel', label: 'Relativity cost', value: metrics.relativityCostUsd, note: '$8 a document' },
            { key: 'avr', label: 'AVR reviewer pay', value: metrics.reviewerPaidUsd, note: '$5 a document' },
            { key: 'save', label: 'AVR saving', value: metrics.savingVersusRelativityUsd, note: `${pct(metrics.savingVersusRelativityUsd, metrics.relativityCostUsd)} of the Relativity cost` },
          ]} format={(value) => usd(value)} />
        </Panel>
        <Panel i={4} title={`Reviews finished by ${unit}`} sub={`All recorded history. The highlighted bars fall in ${model.label}. Hover a bar for its running total.`} action={<Seg label="Group by" size="sm" value={unit} onChange={setUnit} options={UNITS} />}>
          {periods.length ? <PeriodBars points={periods} label={`Reviews finished by ${unit}`} /> : <Empty title="No completed documents in this slice" />}
        </Panel>
      </div>
      <Panel i={2} id="fee" className="fee" title="Where the fee goes" sub={`The client pays $10 for each completed document. Aurora pays the reviewer $5 and keeps $5 as revenue. Relativity would cost $8, so AVR saves $3 on each document, ${pct(metrics.savingVersusRelativityUsd, metrics.relativityCostUsd)} of the Relativity cost.`}>
        <div className="feesplit">
          <Ring size={184} stroke={18} label="Client fees split into reviewer pay and revenue" parts={[
            { label: 'Reviewer paid', value: metrics.reviewerPaidUsd, color: 'var(--svc-2)' },
            { label: 'Revenue', value: metrics.revenueUsd, color: 'var(--svc-0)' },
          ]} center={<><b>{usd(metrics.revenueUsd)}</b><small>revenue</small></>} />
          <dl className="feesplit__facts">
            <div><dt>Documents completed</dt><dd>{num(metrics.completed)}</dd></div>
            <div><dt>Client pays</dt><dd>{usd(metrics.clientPaysUsd)}<small>$10 a document</small></dd></div>
            <div><dt><i style={{ '--c': 'var(--svc-2)' }} />Reviewer paid</dt><dd>{usd(metrics.reviewerPaidUsd)}<small>$5 a document · {pct(metrics.reviewerPaidUsd, metrics.clientPaysUsd)} of the fee</small></dd></div>
            <div><dt><i style={{ '--c': 'var(--svc-0)' }} />Aurora revenue</dt><dd>{usd(metrics.revenueUsd)}<small>$5 a document · {pct(metrics.revenueUsd, metrics.clientPaysUsd)} of the fee</small></dd></div>
            <div><dt>Relativity cost</dt><dd>{usd(metrics.relativityCostUsd)}<small>$8 a document</small></dd></div>
            <div><dt>AVR saving</dt><dd>{usd(metrics.savingVersusRelativityUsd)}<small>$3 a document · {pct(metrics.savingVersusRelativityUsd, metrics.relativityCostUsd)} less than Relativity</small></dd></div>
          </dl>
        </div>
      </Panel>
    </section>
  );
}

function Queues({ model, openDetail }) {
  const [figures, setFigures] = useState('both');
  const metrics = model.metrics;
  const previous = model.previous;
  const items = [
    ['unassigned', 'Unassigned', metrics.unassigned, previous.unassigned, model.directions.unassigned],
    ['assigned', 'Assigned', metrics.assigned, previous.assigned, model.directions.assigned],
    ['in_progress', 'In progress', metrics.inProgress, previous.inProgress, model.directions.inProgress],
    ['completed', 'Documents completed', metrics.completed, previous.completed, model.directions.completed],
  ];
  const total = items.reduce((sum, [, , value]) => sum + value, 0) || 1;
  const max = Math.max(1, ...items.map(([, , value]) => value));
  const open = (event, id, label) => openDetail(event, {
    title: label,
    docs: model.currentDocs.filter((doc) => (id === 'released' ? doc.queue === 'completed' && doc.released : doc.queue === id)),
  });
  return (
    <section id="queues" data-section="queues" aria-label="Queues">
      <header className="doc-head">
        <div className="doc-head__top">
          <div>
            <p className="kicker">Queues · {model.label}</p>
            <Title text="Where the work sits." />
          </div>
        </div>
        <p className="doc-head__lede">{num(total)} documents. {pct(metrics.completed, total)} are completed, and {pct(metrics.released, metrics.completed)} of those are released to production.</p>
      </header>
      <div className="qcards">
        {items.map(([id, label, value, , dir], index) => (
          <Panel key={id} i={index}>
            <button className="qblock" type="button" onClick={(event) => open(event, id, label)}>
              <span className="kicker">{label}</span>
              <FigurePair count={value} share={pct(value, total)} shareLabel="of documents" />
              <Move dir={dir} />
            </button>
          </Panel>
        ))}
      </div>
      <div className="doc-bento">
        <Panel i={4} title="Share of the queue" sub="Bars share one baseline. Height is this period." action={<ShowToggle value={figures} onChange={setFigures} />}>
          <div className="sharebar" aria-hidden="true">
            {items.map(([id, , value]) => <i key={id} style={{ '--c': queueTone(id), width: `${(value / total) * 100}%` }} />)}
          </div>
          <div className="minicols minicols--wide">
            {items.map(([id, label, value, prior]) => (
              <div key={id} className="minicol">
                <b>{figures === 'percent' ? pct(value, total) : num(value)}</b>
                <span className="minicol__track"><i style={{ height: `${Math.round(12 + (value / max) * 108)}px`, background: queueTone(id) }} /></span>
                <span className="minicol__label">{label}{figures === 'both' ? <><br />{pct(value, total)}</> : null}<br />was {pct(prior, previous.unassigned + previous.assigned + previous.inProgress + previous.completed || 1)}</span>
              </div>
            ))}
          </div>
        </Panel>
        <Panel i={5}>
          <button className="qblock" type="button" onClick={(event) => open(event, 'released', 'Released to production')}>
            <span className="kicker">Released to production · of completed</span>
            <span className="released">
              <span className="released__figures">
                <FigurePair count={metrics.released} share={pct(metrics.released, metrics.completed)} shareLabel="of completed" />
                <Move dir={model.directions.released} />
              </span>
              <Ring size={132} stroke={14} label={`${pct(metrics.released, metrics.completed)} of completed documents released`} parts={[
                { label: 'Released', value: metrics.released, color: 'var(--svc-0)' },
                { label: 'Not released', value: Math.max(0, metrics.completed - metrics.released), color: 'var(--ink-4)' },
              ]} center={<b>{pct(metrics.released, metrics.completed)}</b>} />
            </span>
          </button>
          <p className="note">Last period released {pct(previous.released, previous.completed)} of its completed documents to production.</p>
        </Panel>
      </div>
    </section>
  );
}

function Reviewers({ model, person, setPerson, openDetail }) {
  const max = Math.max(1, ...model.reviewers.map((row) => row.completed));
  const done = model.reviewers.reduce((sum, row) => sum + row.completed, 0) || 1;
  const wrong = model.reviewers.reduce((sum, row) => sum + row.misses, 0);
  const checked = model.reviewers.reduce((sum, row) => sum + row.checked, 0);
  const times = useMemo(() => {
    const groups = new Map();
    for (const doc of model.baseDocs) {
      if (!doc.reviewer) continue;
      if (!groups.has(doc.reviewer)) groups.set(doc.reviewer, []);
      groups.get(doc.reviewer).push(doc);
    }
    return new Map([...groups].map(([name, docs]) => [name, timeTotals(docs)]));
  }, [model.baseDocs]);
  const allTime = timeTotals(model.baseDocs.filter((doc) => doc.reviewer));
  return (
    <section id="reviewers" data-section="reviewers" aria-label="Reviewers">
      <header className="doc-head">
        <div className="doc-head__top">
          <div>
            <p className="kicker">Reviewers · {model.label}</p>
            <Title text="How the reviewers are scoring." />
          </div>
        </div>
        <p className="doc-head__lede">{model.reviewers.length} reviewers completed {num(done)} documents. {num(wrong)} misses on the senior sample, {pct(wrong, checked)} of the documents checked. Their documents are estimated at {time(allTime.planned)} in total. Those already reviewed took {time(allTime.actual)} against {time(allTime.estimated)} estimated.</p>
      </header>
      <Panel i={4} title="How the score is calculated" sub="A reviewer finishes coding a batch. A senior reviewer then re-checks a sample, usually about 1 in 10, and codes them again without looking at the first answers.">
        <p>The platform compares the two. If the senior reviewer changes responsive, privileged, or confidential, that document counts as a miss. Misses ÷ documents checked is that reviewer’s score. If the misses are too many, the batch is sent back and the reviewer is corrected. If the sample is clean, the rest of the batch is accepted without being re-read.</p>
        <p className="note">The number beside each name is the same overall score as Intelligence: the average of sample quality, the defect score, and pace. Documents completed are shown in the row and are not part of that score.</p>
      </Panel>
      <Panel i={5} title="Reviewers" sub="The number on the right is the score out of 10. The bar is documents completed. Time shows the estimate for all their documents, then actual against estimate for those reviewed. The gaps compare each reviewer with the average of this list." action={person !== 'All' ? <button className="btn btn--secondary" type="button" onClick={() => setPerson('All')}>All reviewers</button> : null}>
        {model.reviewers.length ? (
          <ol className="rank rank--people">
            {model.reviewers.map((row, index) => (
              <li key={row.reviewer} className={person === row.reviewer ? 'is-self' : ''} style={{ '--k': index }}>
                <button type="button" onClick={(event) => openDetail(event, {
                  title: row.reviewer,
                  note: `${num(row.completed)} documents completed. ${num(row.misses)} misses out of ${num(row.checked)} documents checked. A miss is a senior reviewer changing responsive, privileged, or confidential. Sample quality ${one(row.accuracy)}. Pace ${one(row.timeScore)}. Overall score ${one(row.score)} out of 10. Documents completed are not part of the score.`,
                  docs: model.baseDocs.filter((doc) => doc.reviewer === row.reviewer),
                })}>
                  <span className="rank__n">{String(index + 1).padStart(2, '0')}</span>
                  <span className="mark mark--sm" style={{ '--c': 'var(--svc-1)' }}>{initials(row.reviewer)}</span>
                  <span className="rank__name">
                    {row.reviewer}
                    <small className="muted">{num(row.misses)} misses of {num(row.checked)} checked</small>
                  </span>
                  <span className="rank__volume"><span className="rank__bar"><i style={{ '--v': row.completed / max }} /></span><small>{num(row.completed)} done · {pct(row.completed, done)}</small></span>
                  <span className="rank__time">
                    <span>{time(times.get(row.reviewer)?.planned)} <small>estimated</small></span>
                    <span>{time(times.get(row.reviewer)?.actual)} <small>actual of {time(times.get(row.reviewer)?.estimated)}</small></span>
                  </span>
                  <span className="rank__gaps">
                    <Gap value={row.scoreGap} noun="score" />
                    <Gap value={row.accuracyGap} noun="accuracy" />
                    <Gap value={row.volumeGap} noun="volume" near={1} />
                  </span>
                  <span className="rank__value"><span className={`quality quality--${(row.band || 'none').replace(' ', '-')}`}>{one(row.score)}</span><small>{bandLabel(row.band) || 'No score'}</small></span>
                </button>
              </li>
            ))}
          </ol>
        ) : <Empty title="No reviewers in this slice" text="Widen the period or clear a filter." />}
      </Panel>
    </section>
  );
}

function Tags({ model, openDetail }) {
  const [figures, setFigures] = useState('both');
  const [formFigures, setFormFigures] = useState('both');
  const documents = model.currentDocs.length || 1;
  const reviewable = (model.metrics.assigned + model.metrics.inProgress + model.metrics.completed) || 1;
  const forms = CODING_FORMS.map((form) => {
    const row = model.coding[form] || {};
    const count = QUEUES.reduce((sum, [queue]) => sum + (row[queue] || 0), 0);
    return { form, count };
  });
  const tagRows = heatRows(BOARD_LEVEL_TAGS, model.board).map((row) => ({
    ...row,
    note: `${pct(model.board[row.key]?.documents || 0, documents)} of all documents`,
  }));
  return (
    <section id="tags" data-section="tags" aria-label="Tags">
      <header className="doc-head">
        <div className="doc-head__top">
          <div>
            <p className="kicker">Tags · {model.label}</p>
            <Title text="How the work is tagged." />
          </div>
        </div>
        <p className="doc-head__lede">The percentage under each tag is its share of all {num(documents)} documents. A document can carry more than one tag.</p>
      </header>
      <Panel i={1} title="Board tags" sub="The percentage under the tag name is that tag’s share of all documents." action={<ShowToggle value={figures} onChange={setFigures} />}>
        <Heatmap corner="Tag" onPick={(tag, queueKey) => openDetail(null, {
          title: `${tag} · ${queueName(queueKey)}`,
          docs: model.currentDocs.filter((doc) => doc.queue === queueKey && getBoardLevelTags(doc).includes(tag)),
        })} columns={QUEUES.map(([key, label]) => ({ key, label, short: label }))}
          rows={tagRows}
          format={(item) => <HeatFig item={{ ...item, share: (item.label / documents) * 100 }} figures={figures} />} />
      </Panel>
      <Panel i={2} title="Coding forms" sub="Each ring is that form’s share of all documents. Unassigned documents have no coding form. A document can carry more than one form." action={<ShowToggle value={formFigures} onChange={setFormFigures} />}>
        <div className="size-grid coding-rings">
          {forms.map(({ form, count }, index) => (
            <button key={form} className="qblock" type="button" onClick={(event) => openDetail(event, {
              title: form,
              docs: model.currentDocs.filter((doc) => getCodingForms(doc).includes(form)),
            })}>
              <Ring size={116} stroke={11} label={`${form}, ${pct(count, documents)} of all documents`} parts={[
                { label: form, value: count, color: `var(--svc-${index % 5})` },
                { label: 'Rest', value: Math.max(0, documents - count), color: 'var(--ink-4)' },
              ]} center={formFigures === 'count' ? <b>{num(count)}</b> : <b>{pct(count, documents)}</b>} />
              <span>{form}</span>
              {formFigures === 'both' && <small>{plural(count, 'document')}</small>}
              {formFigures === 'percent' && <small>{pct(count, reviewable)} of documents with a reviewer</small>}
            </button>
          ))}
        </div>
      </Panel>
    </section>
  );
}

function Workload({ model, person, openDetail }) {
  const [figures, setFigures] = useState('both');
  const rows = model.workload;
  const assigned = rows.reduce((sum, row) => sum + row.assigned, 0);
  const progress = rows.reduce((sum, row) => sum + row.inProgress, 0);
  const completed = rows.reduce((sum, row) => sum + row.completed, 0);
  const pool = assigned + progress + completed + model.metrics.unassigned || 1;
  const cards = [
    ['completed', 'Completed', completed, pct(completed, pool)],
    ['in_progress', 'In progress', progress, pct(progress, pool)],
    ['assigned', 'Assigned', assigned, pct(assigned, pool)],
    ['unassigned', 'Unassigned', model.metrics.unassigned, pct(model.metrics.unassigned, pool)],
  ];
  return (
    <section id="workload" data-section="workload" aria-label="Workload">
      <header className="doc-head">
        <div className="doc-head__top">
          <div>
            <p className="kicker">Workload · {model.label}</p>
            <Title text="Who is carrying the work." />
          </div>
        </div>
        <p className="doc-head__lede">{rows.length} reviewers. Unassigned documents have no reviewer, so they sit in the last card rather than on a person row. {pct(model.metrics.released, model.metrics.completed)} of completed documents are released to production.</p>
      </header>
      <div className="qcards">
        {cards.map(([id, label, value, share], index) => (
          <Panel key={id} i={index}>
            <p className="kicker">{label}</p>
            <FigurePair count={value} share={share} shareLabel="of documents" />
          </Panel>
        ))}
      </div>
      <Panel i={4} title="Person to queue" sub="Order is completed, then in progress, then assigned. The percentage is that person’s own work." action={<ShowToggle value={figures} onChange={setFigures} />}>
        {rows.length ? (
          <Heatmap corner="Reviewer" onPick={(reviewer, queueKey) => openDetail(null, {
            title: `${reviewer} · ${queueName(queueKey)}`,
            docs: model.baseDocs.filter((doc) => doc.reviewer === reviewer && doc.queue === queueKey),
            reviewer,
          })} selected={person !== 'All' ? { row: person, col: 'completed' } : undefined}
            columns={[['completed', 'Completed'], ['in_progress', 'In progress'], ['assigned', 'Assigned']].map(([key, label]) => ({ key, label, short: label }))}
            rows={workloadRows(rows)} format={(item) => <HeatFig item={item} figures={figures} />} />
        ) : <Empty title="No assigned work in this slice" />}
      </Panel>
    </section>
  );
}

function Documents({ landing, model, documents, shown, page, pages, setPage, docQuery, setDocQuery, docQueueFilter, setDocQueueFilter, docSize, setDocSize, openDetail }) {
  const counts = Object.fromEntries(landing.mechanism.sizes.map((size) => [size.key, model.currentDocs.filter((doc) => doc.size === size.key).length]));
  const maxCount = Math.max(1, ...Object.values(counts));
  const total = model.currentDocs.length || 1;
  const [figures, setFigures] = useState('both');
  const est = model.metrics.plannedMinutes;
  const prev = model.previous.plannedMinutes;
  const maxMin = Math.max(est, prev, 1);
  const maxPages = Math.max(1, ...shown.map((doc) => doc.pages));
  const sample = model.currentDocs.find((doc) => doc.timed);
  return (
    <section id="documents" data-section="documents" aria-label="Documents">
      <header className="doc-head">
        <div className="doc-head__top">
          <div>
            <p className="kicker">Documents · {model.label}</p>
            <Title text="Every document, in one view." />
          </div>
        </div>
        <p className="doc-head__lede">{num(model.currentDocs.length)} documents across {landing.catalog.projects.length} matters, 3 size bands and 4 queues.</p>
      </header>
      <div className="doc-bento">
        <Panel i={0} title="Documents by size" action={<ShowToggle value={figures} onChange={setFigures} />}>
          <p className="hero-figure"><Count value={model.currentDocs.length} /></p>
          <div className="minicols minicols--tall">
            {landing.mechanism.sizes.map((size, index) => (
              <div key={size.key} className="minicol">
                <b>{figures === 'percent' ? pct(counts[size.key], total) : num(counts[size.key])}</b>
                <span className="minicol__track"><i style={{ height: `${Math.round(16 + (counts[size.key] / maxCount) * 164)}px`, background: `var(--svc-${index})` }} /></span>
                <span className="minicol__label">{size.label}{figures === 'both' ? ` · ${pct(counts[size.key], total)}` : ''}<br />{size.pages}</span>
              </div>
            ))}
          </div>
        </Panel>
        <Panel i={1}>
          <p className="kicker">Estimated minutes, all documents · {model.label}</p>
          <p className="hero-figure"><Count value={est} /></p>
          <p className="est-note"><Move dir={computeDirection(est, prev)} /> compared with {num(prev)} estimated minutes in {model.previousLabel}. Reviewed documents took {num(model.metrics.actualMinutes)} minutes against {num(model.metrics.estimatedMinutes)} estimated.</p>
          <div className="est">
            <div className="est__col">
              <b>{num(prev)}</b>
              <span className="minicol__track"><i style={{ height: `${Math.max(4, (prev / maxMin) * 100)}%`, background: 'var(--ink-3)' }} /></span>
              <span className="minicol__label">{model.previousLabel}</span>
            </div>
            <div className="est__col">
              <b>{num(est)}</b>
              <span className="minicol__track"><i style={{ height: `${Math.max(4, (est / maxMin) * 100)}%`, background: 'var(--svc-1)' }} /></span>
              <span className="minicol__label">{model.label}</span>
            </div>
          </div>
          <p className="note">Estimate = {landing.mechanism.formula}. A plain English page is {landing.mechanism.pageMinutes} minutes. {landing.mechanism.example}</p>
        </Panel>
      </div>
      <div className="size-grid">
        {landing.mechanism.sizes.map((size, index) => (
          <Panel key={size.key} className="size-card" i={index} title={size.label} sub={size.pages}>
            <Ring size={96} stroke={10} label={`${size.label} documents`} parts={[
              { label: size.label, value: counts[size.key], color: `var(--svc-${index})` },
              { label: 'Other', value: Math.max(0, total - counts[size.key]), color: 'var(--ink-4)' },
            ]} center={<b>{((counts[size.key] / total) * 100).toFixed(0)}%</b>} />
            <p className="note"><b><Count value={counts[size.key]} /></b> documents</p>
          </Panel>
        ))}
      </div>
      <div className="doc-stack">
        <Panel i={3} title="How size and time are calculated" sub={landing.mechanism.score}>
          <dl className="mech">
            {landing.mechanism.sizes.map((size) => <div key={size.key}><dt>{size.label}</dt><dd>{size.pages}</dd></div>)}
            {landing.mechanism.weights.map(([label, weight]) => <div key={label}><dt>{label}</dt><dd>weight {weight}</dd></div>)}
            <div><dt>Estimate</dt><dd>{landing.mechanism.formula}</dd></div>
          </dl>
          {sample && <p className="note">{sample.title}: {sample.pages} pages, {sample.language.toLowerCase()} ×{sample.languageWeight}, {sample.content} ×{sample.contentWeight}, {sample.regionName} ×{sample.regionWeight} = {sample.estimatedMinutes} estimated minutes. Actual time was {sample.actualMinutes} minutes.</p>}
        </Panel>
        <Panel i={4} title="Documents" sub={`${num(documents.length)} matching`}>
          <div className="filters">
            <label className="search-field">Name<input value={docQuery} placeholder="Email, contract, id" onChange={(event) => setDocQuery(event.target.value)} /></label>
            <Select label="Queue" value={docQueueFilter} onChange={setDocQueueFilter} options={[['All', 'All queues'], ...QUEUES, ['released', 'Released to production']]} />
            <Select label="Size" value={docSize} onChange={setDocSize} options={[['All', 'All sizes'], ...landing.mechanism.sizes.map((size) => [size.key, size.label])]} />
          </div>
          {shown.length ? (
            <ol className="rank">
              {shown.map((doc, index) => (
                <li key={doc.id} style={{ '--k': index }}>
                  <button type="button" onClick={(event) => openDetail(event, { title: doc.title, docs: [doc], single: true })}>
                    <span className="rank__n">{String((page - 1) * PAGE + index + 1).padStart(2, '0')}</span>
                    <span className="mark mark--sm" style={{ '--c': queueTone(doc.queue) }}>{initials(doc.reviewer || 'Unassigned')}</span>
                    <span className="rank__name">{doc.title}<small className="muted">{doc.id} · {doc.reviewer || 'Unassigned'} · {docQueue(doc)}</small><span className="rank__bar"><i style={{ '--v': doc.pages / maxPages }} /></span></span>
                    <span className="rank__value">{doc.size[0].toUpperCase()}{doc.size.slice(1)}<small>{plural(doc.pages, 'page')} · {time(doc.estimatedMinutes)} estimated{doc.actualMinutes != null ? ` · ${time(doc.actualMinutes)} actual` : ''}</small></span>
                  </button>
                </li>
              ))}
            </ol>
          ) : <Empty title="No documents match" text="Clear the name, queue or size filter." />}
          {documents.length > PAGE && (
            <div className="pager">
              <span className="muted">{(page - 1) * PAGE + 1}–{Math.min(page * PAGE, documents.length)} of {num(documents.length)}</span>
              <button className="btn btn--secondary" type="button" disabled={page === 1} onClick={() => setPage((n) => n - 1)}>Previous</button>
              <button className="btn btn--secondary" type="button" disabled={page === pages} onClick={() => setPage((n) => n + 1)}>Next</button>
            </div>
          )}
        </Panel>
      </div>
    </section>
  );
}

function Detail({ detail, onClose, onDismiss, onOpen }) {
  const [page, setPage] = useState(1);
  const listKey = `${detail.title}:${detail.single ? 'one' : 'list'}`;
  useEffect(() => { setPage(1); }, [listKey]);
  const drawerPage = 20;
  const pages = Math.max(1, Math.ceil(detail.docs.length / drawerPage));
  const start = (page - 1) * drawerPage;
  const rows = detail.single ? [] : detail.docs.slice(start, start + drawerPage);
  const doc = detail.single ? detail.docs[0] : null;
  return (
    <div className="drawer" role="dialog" aria-modal="true" aria-label={detail.title}>
      <button className="drawer__scrim" type="button" aria-label="Close" onClick={onDismiss} />
      <div className="drawer__panel">
        <div className="drawer__head">
          <button id="detail-close" className="btn btn--ghost" type="button" onClick={onClose}>Back</button>
          {!doc && <span className="muted">{plural(detail.docs.length, 'document')}</span>}
        </div>
        <h2>{detail.title}</h2>
        {detail.note && <p className="drawer__note">{detail.note}</p>}
        {doc ? <DocFacts doc={doc} /> : <TimeSummary docs={detail.docs} />}
        {rows.map((item) => (
          <button key={item.id} type="button" className="drawer__doc" onClick={() => onOpen(item)}>
            <span><b>{item.title}</b><small>{item.reviewer || 'Unassigned'} · {docQueue(item)} · {capital(item.size)}, {plural(item.pages, 'page')}</small></span>
            <span className="drawer__time"><b>{time(item.estimatedMinutes)}</b><small>{item.actualMinutes != null ? `${time(item.actualMinutes)} actual` : 'estimated'}</small></span>
          </button>
        ))}
        {!detail.single && !rows.length && <Empty title="Nothing in this selection" text="Unassigned work has no reviewer, so a reviewer filter hides it." />}
        {!detail.single && detail.docs.length > drawerPage && (
          <div className="pager">
            <span className="muted">{start + 1}–{Math.min(start + drawerPage, detail.docs.length)} of {num(detail.docs.length)}</span>
            <button className="btn btn--secondary" type="button" disabled={page === 1} onClick={() => setPage((n) => n - 1)}>Previous</button>
            <button className="btn btn--secondary" type="button" disabled={page === pages} onClick={() => setPage((n) => n + 1)}>Next</button>
          </div>
        )}
      </div>
    </div>
  );
}

function timeGap(estimated, actual) {
  const gap = actual - estimated;
  if (!gap) return 'On the estimate';
  return `${time(Math.abs(gap))} ${gap > 0 ? 'over' : 'under'} the estimate`;
}

function TimeSummary({ docs }) {
  const totals = timeTotals(docs);
  return (
    <div className="timecards">
      <div><span>Estimated, all documents</span><b>{time(totals.planned)}</b><small>{plural(totals.documents, 'document')}</small></div>
      <div><span>Actual, reviewed documents</span><b>{totals.reviewed ? time(totals.actual) : 'Not reviewed'}</b><small>{totals.reviewed ? `${plural(totals.reviewed, 'document')} · ${time(totals.estimated)} estimated · ${timeGap(totals.estimated, totals.actual)}` : 'None of these has finished review'}</small></div>
    </div>
  );
}

function DocFacts({ doc }) {
  const reviewed = doc.actualMinutes != null;
  const region = doc.regionWeight ?? 1;
  return (
    <>
      <div className="timecards">
        <div><span>Estimated time</span><b>{time(doc.estimatedMinutes)}</b><small>{doc.pages} × {doc.languageWeight} language × {doc.contentWeight} content × {region} region × 4</small></div>
        <div><span>Actual time</span><b>{reviewed ? time(doc.actualMinutes) : 'Not reviewed'}</b><small>{reviewed ? timeGap(doc.estimatedMinutes, doc.actualMinutes) : `${docQueue(doc)}, so no time is recorded yet`}</small></div>
      </div>
      <dl className="docfacts">
        <div><dt>Queue</dt><dd>{docQueue(doc)}</dd></div>
        <div><dt>Reviewer</dt><dd>{doc.reviewer || 'Unassigned'}</dd></div>
        <div><dt>Client</dt><dd>{doc.client}</dd></div>
        <div><dt>Project</dt><dd>{doc.projectName}</dd></div>
        <div><dt>Size</dt><dd>{capital(doc.size)} · {plural(doc.pages, 'page')}</dd></div>
        <div><dt>Language</dt><dd>{doc.language} · weight {doc.languageWeight}</dd></div>
        <div><dt>Content</dt><dd>{capital(doc.content)} · weight {doc.contentWeight}</dd></div>
        <div><dt>Region</dt><dd>{doc.regionName || 'Not set'} · weight {region}</dd></div>
        <div><dt>Date</dt><dd>{longDate(doc.date)}</dd></div>
      </dl>
    </>
  );
}

function Figure({ onClick, value, format, label, dir, tags }) {
  return (
    <li className="rise">
      <button className="head" type="button" onClick={onClick}>
        <span className="head__value">{typeof value === 'number' ? <Count value={value} format={format} /> : 'N/A'}</span>
        <span className="head__label">{label}</span>
        <span className="head__tags"><Move dir={dir} />{tags.filter(Boolean).map((tag) => <span key={tag}>{tag}</span>)}</span>
      </button>
    </li>
  );
}

function HeatFig({ item, figures = 'both' }) {
  const share = item.share != null && !item.empty ? `${item.share.toFixed(0)}%` : null;
  if (figures === 'count') return <span className="heat-fig"><b>{num(item.label)}</b></span>;
  if (figures === 'percent') return <span className="heat-fig"><b>{share || '—'}</b></span>;
  return <span className="heat-fig"><b>{num(item.label)}</b>{share ? <small>{share}</small> : null}</span>;
}

function figureText(figures, value, whole) {
  if (figures === 'count') return num(value);
  if (figures === 'percent') return pct(value, whole);
  return `${num(value)} · ${pct(value, whole)}`;
}

function FigurePair({ figures = 'both', count, share, shareLabel }) {
  return (
    <span className="figure-pair">
      <span className="hero-figure hero-figure--sm">{figures === 'percent' ? share : <Count value={count} />}</span>
      {figures !== 'count' && <span className="qblock__share">{figures === 'percent' ? shareLabel : `${share} ${shareLabel}`}</span>}
    </span>
  );
}

function underTag(metrics, model) {
  const under = metrics.reviewersUnder7List || [];
  if (!model.showUnder || !under.length) return '';
  const names = under.slice(0, 3).map((row) => `${row.name} ${row.score.toFixed(1)}`).join(', ');
  const more = under.length > 3 ? ` +${under.length - 3}` : '';
  return `${pct(under.length, model.names.length)} under 7: ${names}${more}`;
}

function workloadRows(rows) {
  const max = Math.max(1, ...rows.flatMap((row) => [row.assigned, row.inProgress, row.completed, row.released]));
  return rows.map((row) => {
    const total = row.assigned + row.inProgress + row.completed || 1;
    return {
      key: row.reviewer,
      label: row.reviewer,
      cells: [
        [row.completed, row.completed / total, 'of their work'],
        [row.inProgress, row.inProgress / total, 'of their work'],
        [row.assigned, row.assigned / total, 'of their work'],
      ].map(([count, share, basis]) => ({
        v: count / max,
        label: count,
        share: share * 100,
        aria: `${count} documents, ${(share * 100).toFixed(0)} percent ${basis}`,
      })),
    };
  });
}
