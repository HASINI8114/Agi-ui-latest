import { workspaceConfig } from '../../scripts/vite-config.js';
export default workspaceConfig('review', new URL('.', import.meta.url));
